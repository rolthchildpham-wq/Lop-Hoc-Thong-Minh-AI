package vn.aihuedan.learn;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String LIVE_URL = "https://aihuedanlearn.edgeone.dev/";
    private static final String LOCAL_URL = "file:///android_asset/www/index.html";
    private WebView webView;
    private PermissionRequest pendingWebPermission;
    private static final int REQ_WEB_PERMS=71;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        webView=new WebView(this); setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT); s.setTextZoom(100);
        if(android.os.Build.VERSION.SDK_INT>=21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient(){
            @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err){
                if(req.isForMainFrame() && !view.getUrl().startsWith("file:///android_asset/")){
                    Toast.makeText(MainActivity.this,"Mất mạng — chuyển sang chế độ học offline",Toast.LENGTH_SHORT).show();
                    view.loadUrl(LOCAL_URL);
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public void onPermissionRequest(PermissionRequest request){
                runOnUiThread(()->handleWebPermission(request));
            }
        });
        if(isOnline()) webView.loadUrl(LIVE_URL); else webView.loadUrl(LOCAL_URL);
    }

    private boolean isOnline(){
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if(cm==null)return false; Network n=cm.getActiveNetwork(); if(n==null)return false;
        NetworkCapabilities c=cm.getNetworkCapabilities(n); return c!=null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }
    private void handleWebPermission(PermissionRequest request){
        boolean mic=false,cam=false;
        for(String r:request.getResources()){
            if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r))mic=true;
            if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r))cam=true;
        }
        boolean needMic=mic && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED;
        boolean needCam=cam && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED;
        if(needMic||needCam){
            pendingWebPermission=request;
            java.util.ArrayList<String> ps=new java.util.ArrayList<>(); if(needMic)ps.add(Manifest.permission.RECORD_AUDIO); if(needCam)ps.add(Manifest.permission.CAMERA);
            requestPermissions(ps.toArray(new String[0]),REQ_WEB_PERMS);
        }else request.grant(request.getResources());
    }
    @Override public void onRequestPermissionsResult(int rc,String[] p,int[] g){
        super.onRequestPermissionsResult(rc,p,g);
        if(rc==REQ_WEB_PERMS && pendingWebPermission!=null){
            boolean all=true;for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED)all=false;
            if(all)pendingWebPermission.grant(pendingWebPermission.getResources()); else pendingWebPermission.deny(); pendingWebPermission=null;
        }
    }
    @Override public void onBackPressed(){ if(webView!=null&&webView.canGoBack())webView.goBack(); else super.onBackPressed(); }
    @Override protected void onPause(){super.onPause();if(webView!=null)webView.onPause();}
    @Override protected void onResume(){super.onResume();if(webView!=null)webView.onResume();}
    @Override protected void onDestroy(){if(webView!=null){webView.destroy();webView=null;}super.onDestroy();}
}
