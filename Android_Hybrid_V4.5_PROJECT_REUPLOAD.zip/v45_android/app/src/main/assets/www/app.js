const DATA_BANK = {
    english: {
        comm: [
            { word: "GREET", type: "Giao tiếp", situation: "Gặp gỡ", vi: "Chào hỏi, đón tiếp", ipa: "/ɡriːt/", hook: "Âm /iː/ kéo dài, bật nhẹ /t/ cuối.", context: "He greeted me with a warm smile." },
            { word: "HELLO", type: "Giao tiếp", situation: "Chào hỏi", vi: "Xin chào", ipa: "/həˈləʊ/", hook: "Nhấn âm 2.", context: "Hello, nice to meet you." },
            { word: "PLEASE", type: "Giao tiếp", situation: "Lịch sự", vi: "Làm ơn", ipa: "/pliːz/", hook: "Kéo dài /iː/.", context: "Please sit down." },
            { word: "THANKS", type: "Giao tiếp", situation: "Cảm ơn", vi: "Cảm ơn", ipa: "/θæŋks/", hook: "Âm /θ/ đặt lưỡi nhẹ giữa răng.", context: "Thanks for your help." },
            { word: "SORRY", type: "Giao tiếp", situation: "Xin lỗi", vi: "Xin lỗi", ipa: "/ˈsɒr.i/", hook: "Nhấn âm 1.", context: "Sorry, I am late." },
            { word: "WELCOME", type: "Giao tiếp", situation: "Đón tiếp", vi: "Chào mừng", ipa: "/ˈwel.kəm/", hook: "Nhấn âm đầu.", context: "Welcome to our class." },
            { word: "FAVOR", type: "Giao tiếp", situation: "Nhờ vả", vi: "Sự giúp đỡ, ân huệ", ipa: "/ˈfeɪ.vər/", hook: "Do me a favor.", context: "Could you do me a favor?" },
            { word: "POLITE", type: "Giao tiếp", situation: "Ứng xử", vi: "Lịch sự", ipa: "/pəˈlaɪt/", hook: "Nhấn âm 2.", context: "It is polite to say thank you." },
            { word: "LISTEN", type: "Giao tiếp", situation: "Trong lớp", vi: "Lắng nghe", ipa: "/ˈlɪs.ən/", hook: "Chữ t câm.", context: "Please listen carefully." },
            { word: "SPEAK", type: "Giao tiếp", situation: "Nói chuyện", vi: "Nói", ipa: "/spiːk/", hook: "Âm /iː/ dài.", context: "Can you speak English?" },
            { word: "ANSWER", type: "Giao tiếp", situation: "Trong lớp", vi: "Trả lời", ipa: "/ˈɑːn.sər/", hook: "W câm.", context: "Please answer the question." },
            { word: "QUESTION", type: "Giao tiếp", situation: "Trong lớp", vi: "Câu hỏi", ipa: "/ˈkwes.tʃən/", hook: "Nhấn âm đầu.", context: "I have a question." },
            { word: "AGREE", type: "Giao tiếp", situation: "Thảo luận", vi: "Đồng ý", ipa: "/əˈɡriː/", hook: "Nhấn âm 2.", context: "I agree with you." },
            { word: "EXPLAIN", type: "Giao tiếp", situation: "Giải thích", vi: "Giải thích", ipa: "/ɪkˈspleɪn/", hook: "Nhấn âm 2.", context: "Can you explain it again?" },
            { word: "REPEAT", type: "Giao tiếp", situation: "Nghe chưa rõ", vi: "Lặp lại", ipa: "/rɪˈpiːt/", hook: "Nhấn âm 2.", context: "Please repeat that." },
            { word: "UNDERSTAND", type: "Giao tiếp", situation: "Học tập", vi: "Hiểu", ipa: "/ˌʌn.dəˈstænd/", hook: "Nhấn âm cuối.", context: "I understand the lesson." },
            { word: "FRIEND", type: "Giao tiếp", situation: "Bạn bè", vi: "Bạn bè", ipa: "/frend/", hook: "IE đọc /e/.", context: "She is my best friend." },
            { word: "MEET", type: "Giao tiếp", situation: "Làm quen", vi: "Gặp", ipa: "/miːt/", hook: "EE = /iː/.", context: "Nice to meet you." },
            { word: "INVITE", type: "Giao tiếp", situation: "Mời", vi: "Mời", ipa: "/ɪnˈvaɪt/", hook: "Nhấn âm 2.", context: "I want to invite you." },
            { word: "HELP", type: "Giao tiếp", situation: "Hỗ trợ", vi: "Giúp đỡ", ipa: "/help/", hook: "Âm cuối /p/ rõ.", context: "Can I help you?" }
        ],
        travel: [
            { word: "FLIGHT", type: "Du lịch", situation: "Sân bay", vi: "Chuyến bay", ipa: "/flaɪt/", hook: "GH câm.", context: "Have a safe flight!" },
            { word: "HOTEL", type: "Du lịch", situation: "Đặt phòng", vi: "Khách sạn", ipa: "/həʊˈtel/", hook: "Nhấn âm 2.", context: "I booked a hotel near the beach." },
            { word: "TICKET", type: "Du lịch", situation: "Đặt vé", vi: "Vé", ipa: "/ˈtɪk.ɪt/", hook: "Nhấn âm đầu.", context: "I bought a train ticket." },
            { word: "AIRPORT", type: "Du lịch", situation: "Sân bay", vi: "Sân bay", ipa: "/ˈeə.pɔːt/", hook: "Nhấn âm đầu.", context: "We arrived at the airport early." },
            { word: "PASSPORT", type: "Du lịch", situation: "Xuất nhập cảnh", vi: "Hộ chiếu", ipa: "/ˈpɑːs.pɔːt/", hook: "Nhấn âm đầu.", context: "Show me your passport, please." },
            { word: "LUGGAGE", type: "Du lịch", situation: "Hành lý", vi: "Hành lý", ipa: "/ˈlʌɡ.ɪdʒ/", hook: "Không thêm s khi nói chung.", context: "My luggage is heavy." },
            { word: "STATION", type: "Du lịch", situation: "Tàu xe", vi: "Nhà ga", ipa: "/ˈsteɪ.ʃən/", hook: "-tion = /ʃən/.", context: "The station is near here." },
            { word: "MAP", type: "Du lịch", situation: "Chỉ đường", vi: "Bản đồ", ipa: "/mæp/", hook: "Âm /æ/ mở miệng rộng.", context: "Can I see the map?" },
            { word: "BEACH", type: "Du lịch", situation: "Nghỉ dưỡng", vi: "Bãi biển", ipa: "/biːtʃ/", hook: "EA = /iː/.", context: "The beach is beautiful." },
            { word: "MOUNTAIN", type: "Du lịch", situation: "Thiên nhiên", vi: "Núi", ipa: "/ˈmaʊn.tɪn/", hook: "Nhấn âm đầu.", context: "We climbed the mountain." },
            { word: "MUSEUM", type: "Du lịch", situation: "Tham quan", vi: "Bảo tàng", ipa: "/mjuˈziː.əm/", hook: "Nhấn âm giữa.", context: "Let's visit the museum." },
            { word: "TEMPLE", type: "Du lịch", situation: "Tham quan", vi: "Đền, chùa", ipa: "/ˈtem.pəl/", hook: "Nhấn âm đầu.", context: "This temple is very old." },
            { word: "MARKET", type: "Du lịch", situation: "Mua sắm", vi: "Chợ", ipa: "/ˈmɑː.kɪt/", hook: "Nhấn âm đầu.", context: "We went to the night market." },
            { word: "JOURNEY", type: "Du lịch", situation: "Hành trình", vi: "Hành trình", ipa: "/ˈdʒɜː.ni/", hook: "Nhấn âm đầu.", context: "It was a long journey." },
            { word: "TRAVEL", type: "Du lịch", situation: "Chung", vi: "Du lịch", ipa: "/ˈtræv.əl/", hook: "Nhấn âm đầu.", context: "I love to travel." },
            { word: "TOURIST", type: "Du lịch", situation: "Khách tham quan", vi: "Khách du lịch", ipa: "/ˈtʊə.rɪst/", hook: "Nhấn âm đầu.", context: "Many tourists visit Hanoi." },
            { word: "GUIDE", type: "Du lịch", situation: "Hướng dẫn", vi: "Hướng dẫn viên", ipa: "/ɡaɪd/", hook: "UI đọc /aɪ/.", context: "Our guide speaks English." },
            { word: "BOOKING", type: "Du lịch", situation: "Đặt dịch vụ", vi: "Việc đặt chỗ", ipa: "/ˈbʊk.ɪŋ/", hook: "Nhấn âm đầu.", context: "I confirmed my booking." },
            { word: "DEPARTURE", type: "Du lịch", situation: "Sân bay", vi: "Sự khởi hành", ipa: "/dɪˈpɑː.tʃər/", hook: "Nhấn âm 2.", context: "Check the departure time." },
            { word: "ARRIVAL", type: "Du lịch", situation: "Sân bay", vi: "Sự đến nơi", ipa: "/əˈraɪ.vəl/", hook: "Nhấn âm 2.", context: "The arrival time is 8 p.m." }
        ],
        life: [
            { word: "RECIPE", type: "Cuộc sống", situation: "Nấu ăn", vi: "Công thức nấu ăn", ipa: "/ˈres.ɪ.pi/", hook: "3 âm tiết.", context: "Can you share your pho recipe?" },
            { word: "BUDGET", type: "Cuộc sống", situation: "Chi tiêu", vi: "Ngân sách", ipa: "/ˈbʌdʒ.ɪt/", hook: "Nhấn âm đầu.", context: "This fits our family budget." },
            { word: "BREAKFAST", type: "Cuộc sống", situation: "Bữa ăn", vi: "Bữa sáng", ipa: "/ˈbrek.fəst/", hook: "Nhấn âm đầu.", context: "I eat breakfast at seven." },
            { word: "DINNER", type: "Cuộc sống", situation: "Bữa ăn", vi: "Bữa tối", ipa: "/ˈdɪn.ər/", hook: "Nhấn âm đầu.", context: "We have dinner together." },
            { word: "KITCHEN", type: "Cuộc sống", situation: "Nhà cửa", vi: "Nhà bếp", ipa: "/ˈkɪtʃ.ən/", hook: "TCH = /tʃ/.", context: "Mom is in the kitchen." },
            { word: "BEDROOM", type: "Cuộc sống", situation: "Nhà cửa", vi: "Phòng ngủ", ipa: "/ˈbed.ruːm/", hook: "Ghép bed + room.", context: "My bedroom is upstairs." },
            { word: "CLEAN", type: "Cuộc sống", situation: "Việc nhà", vi: "Dọn dẹp, sạch", ipa: "/kliːn/", hook: "EA = /iː/.", context: "I clean my room every day." },
            { word: "COOK", type: "Cuộc sống", situation: "Nấu ăn", vi: "Nấu ăn", ipa: "/kʊk/", hook: "OO đọc ngắn /ʊ/.", context: "I can cook noodles." },
            { word: "SHOPPING", type: "Cuộc sống", situation: "Mua sắm", vi: "Mua sắm", ipa: "/ˈʃɒp.ɪŋ/", hook: "Nhấn âm đầu.", context: "We go shopping on Sunday." },
            { word: "MONEY", type: "Cuộc sống", situation: "Tài chính", vi: "Tiền", ipa: "/ˈmʌn.i/", hook: "O đọc /ʌ/.", context: "Save your money." },
            { word: "HEALTH", type: "Cuộc sống", situation: "Sức khỏe", vi: "Sức khỏe", ipa: "/helθ/", hook: "TH = /θ/.", context: "Health is important." },
            { word: "EXERCISE", type: "Cuộc sống", situation: "Thể dục", vi: "Tập thể dục", ipa: "/ˈek.sə.saɪz/", hook: "Nhấn âm đầu.", context: "I exercise every morning." },
            { word: "HOBBY", type: "Cuộc sống", situation: "Sở thích", vi: "Sở thích", ipa: "/ˈhɒb.i/", hook: "Nhấn âm đầu.", context: "Reading is my hobby." },
            { word: "MUSIC", type: "Cuộc sống", situation: "Giải trí", vi: "Âm nhạc", ipa: "/ˈmjuː.zɪk/", hook: "Nhấn âm đầu.", context: "I like listening to music." },
            { word: "MOVIE", type: "Cuộc sống", situation: "Giải trí", vi: "Bộ phim", ipa: "/ˈmuː.vi/", hook: "Nhấn âm đầu.", context: "Let's watch a movie." },
            { word: "WEEKEND", type: "Cuộc sống", situation: "Thời gian", vi: "Cuối tuần", ipa: "/ˌwiːkˈend/", hook: "Nhấn âm cuối.", context: "What do you do at the weekend?" },
            { word: "FAMILY", type: "Cuộc sống", situation: "Gia đình", vi: "Gia đình", ipa: "/ˈfæm.əl.i/", hook: "Nhấn âm đầu.", context: "I love my family." },
            { word: "HOMEWORK", type: "Cuộc sống", situation: "Học tập", vi: "Bài tập về nhà", ipa: "/ˈhəʊm.wɜːk/", hook: "Ghép home + work.", context: "I do my homework after dinner." },
            { word: "WEATHER", type: "Cuộc sống", situation: "Thời tiết", vi: "Thời tiết", ipa: "/ˈweð.ər/", hook: "TH hữu thanh /ð/.", context: "The weather is nice today." },
            { word: "GARDEN", type: "Cuộc sống", situation: "Nhà cửa", vi: "Khu vườn", ipa: "/ˈɡɑː.dən/", hook: "Nhấn âm đầu.", context: "There are flowers in the garden." }
        ]
    },
    grade5_math: [
        { topic: "Toán 5: Phân số & Hỗn số", summary: "Hỗn số gồm phần nguyên và phân số nhỏ hơn 1.", question: "Chuyển hỗn số 3 và 2/5 thành phân số:", options: ["17/5", "13/5", "15/2", "16/5"], correct: 0, explain: "3 x 5 + 2 = 17, mẫu giữ nguyên 5." },
        { topic: "Toán 5: Số thập phân", summary: "Cộng trừ số thập phân thẳng hàng dấu phẩy.", question: "Kết quả của 45.6 + 8.92 là:", options: ["54.52", "53.52", "55.52", "54.42"], correct: 0, explain: "45.60 + 8.92 = 54.52." }
    ],
    grade5_viet: [
        { topic: "Tiếng Việt 5: Từ nhiều nghĩa", summary: "Nghĩa gốc và nghĩa chuyển có liên quan mật thiết.", question: "Trong câu 'Bé đang ăn cơm', từ 'ăn' mang nghĩa:", options: ["Nghĩa chuyển", "Nghĩa gốc (hoạt động nhai nuốt)", "Từ đồng âm", "Từ trái nghĩa"], correct: 1, explain: "Ăn cơm là hoạt động vật lý gốc." }
    ],
    grade5_eng: [
        { topic: "Tiếng Anh Lớp 5", summary: "Hỏi đáp tần suất: How often do you have English?", question: "Chọn câu trả lời cho: 'How often do you have IT classes?'", options: ["I like IT very much.", "Twice a week.", "By bus.", "It is red."], correct: 1, explain: "Twice a week chỉ tần suất buổi học." }
    ],
    chinese_hsk: {
        1: [
            {topic:"HSK 1 • Chào hỏi",hanzi:"你好",pinyin:"nǐ hǎo",vn:"Xin chào",summary:"你好 (nǐ hǎo) = Xin chào. Thanh 3 + thanh 3 khi nói liền thường biến điệu tự nhiên.",question:"'你好' có nghĩa là gì?",options:["Cảm ơn","Xin chào","Tạm biệt","Xin lỗi"],correct:1,explain:"你好 (nǐ hǎo) nghĩa là Xin chào."},
            {topic:"HSK 1 • Cảm ơn",hanzi:"谢谢",pinyin:"xiè xie",vn:"Cảm ơn",summary:"谢谢 (xiè xie) dùng để cảm ơn. Âm đầu x đọc nhẹ, đầu lưỡi thấp.",question:"Chọn Pinyin đúng của 谢谢:",options:["zài jiàn","xiè xie","duì bu qǐ","nǐ hǎo"],correct:1,explain:"谢谢 đọc là xiè xie."}
        ],
        2: [
            {topic:"HSK 2 • Sinh hoạt",hanzi:"我每天喝茶。",pinyin:"Wǒ měitiān hē chá.",vn:"Tôi uống trà mỗi ngày.",summary:"每天 (měitiān) = mỗi ngày; cấu trúc: Chủ ngữ + thời gian + động từ + tân ngữ.",question:"Từ nào có nghĩa là 'mỗi ngày'?",options:["今天","每天","明天","昨天"],correct:1,explain:"每天 (měitiān) = mỗi ngày."},
            {topic:"HSK 2 • Khả năng",hanzi:"我会说汉语。",pinyin:"Wǒ huì shuō Hànyǔ.",vn:"Tôi biết nói tiếng Trung.",summary:"会 (huì) diễn tả kỹ năng đã học được.",question:"Trong câu '我会说汉语', 会 biểu thị điều gì?",options:["Địa điểm","Khả năng/kỹ năng","Số lượng","Thời gian"],correct:1,explain:"会 thường chỉ khả năng/kỹ năng đã học."}
        ],
        3: [
            {topic:"HSK 3 • Hội thoại",hanzi:"你觉得这本书怎么样？",pinyin:"Nǐ juéde zhè běn shū zěnmeyàng?",vn:"Bạn thấy cuốn sách này thế nào?",summary:"觉得 (juéde) = cảm thấy/cho rằng; 怎么样 = thế nào.",question:"'怎么样' dùng để hỏi về:",options:["Giá tiền","Đánh giá/cảm nhận","Tuổi","Số điện thoại"],correct:1,explain:"怎么样 dùng để hỏi 'thế nào', xin đánh giá/cảm nhận."},
            {topic:"HSK 3 • So sánh",hanzi:"今天比昨天冷。",pinyin:"Jīntiān bǐ zuótiān lěng.",vn:"Hôm nay lạnh hơn hôm qua.",summary:"A 比 B + tính từ = A ... hơn B.",question:"Cấu trúc so sánh hơn cơ bản là:",options:["A 在 B","A 比 B + tính từ","A 和 B 吗","A 给 B"],correct:1,explain:"Dùng A 比 B + tính từ để so sánh hơn."}
        ],
        4: [
            {topic:"HSK 4 • Giao tiếp mở rộng",hanzi:"虽然下雨，但是我们还是出发了。",pinyin:"Suīrán xiàyǔ, dànshì wǒmen háishi chūfā le.",vn:"Mặc dù trời mưa, nhưng chúng tôi vẫn xuất phát.",summary:"虽然...但是... = mặc dù... nhưng...",question:"Cặp liên từ nào mang nghĩa 'mặc dù... nhưng...' ?",options:["因为...所以...","虽然...但是...","如果...就...","不但...而且..."],correct:1,explain:"虽然...但是... là cặp liên từ nhượng bộ."},
            {topic:"HSK 4 • Kết quả",hanzi:"我终于把作业做完了。",pinyin:"Wǒ zhōngyú bǎ zuòyè zuòwán le.",vn:"Cuối cùng tôi cũng làm xong bài tập.",summary:"把 + tân ngữ + động từ + kết quả nhấn mạnh việc xử lý tân ngữ.",question:"Trong câu này, '完' biểu thị:",options:["Bắt đầu","Kết quả hoàn thành","Phủ định","Câu hỏi"],correct:1,explain:"完 là bổ ngữ kết quả, nghĩa là làm xong."}
        ],
        5: [
            {topic:"HSK 5 • Đọc hiểu",hanzi:"坚持学习比偶尔努力更重要。",pinyin:"Jiānchí xuéxí bǐ ǒu'ěr nǔlì gèng zhòngyào.",vn:"Kiên trì học tập quan trọng hơn việc thỉnh thoảng mới cố gắng.",summary:"坚持 = kiên trì; 偶尔 = thỉnh thoảng; 更 = càng/hơn.",question:"'坚持' gần nghĩa nhất với:",options:["Từ bỏ","Kiên trì","Do dự","Quên"],correct:1,explain:"坚持 nghĩa là kiên trì, tiếp tục làm một việc."},
            {topic:"HSK 5 • Diễn đạt",hanzi:"这次经历给我留下了深刻的印象。",pinyin:"Zhè cì jīnglì gěi wǒ liúxià le shēnkè de yìnxiàng.",vn:"Trải nghiệm này đã để lại cho tôi ấn tượng sâu sắc.",summary:"留下印象 = để lại ấn tượng; 深刻 = sâu sắc.",question:"Cụm '留下印象' có nghĩa là:",options:["Để lại ấn tượng","Đặt lịch hẹn","Gửi thư","Thay đổi kế hoạch"],correct:0,explain:"留下印象 = để lại ấn tượng."}
        ],
        6: [
            {topic:"HSK 6 • Đọc hiểu nâng cao",hanzi:"与其抱怨环境，不如主动寻找解决办法。",pinyin:"Yǔqí bàoyuàn huánjìng, bùrú zhǔdòng xúnzhǎo jiějué bànfǎ.",vn:"Thay vì than phiền về hoàn cảnh, chi bằng chủ động tìm cách giải quyết.",summary:"与其...不如... = thay vì... chi bằng...",question:"Cấu trúc '与其...不如...' dùng để:",options:["Nêu nguyên nhân","Đưa ra lựa chọn ưu tiên","Chỉ thời gian","Liệt kê"],correct:1,explain:"与其...不如... so sánh hai lựa chọn và ưu tiên lựa chọn sau."},
            {topic:"HSK 6 • Sắc thái",hanzi:"他的解释看似合理，实际上却经不起推敲。",pinyin:"Tā de jiěshì kànsì hélǐ, shíjìshang què jīngbuqǐ tuīqiāo.",vn:"Lời giải thích của anh ấy có vẻ hợp lý, nhưng thực tế lại không chịu được sự xem xét kỹ.",summary:"看似 = có vẻ; 实际上 = trên thực tế; 经不起推敲 = không đứng vững khi xem xét kỹ.",question:"'看似' gần nghĩa nhất với:",options:["Chắc chắn là","Có vẻ như","Hoàn toàn không","Ngay lập tức"],correct:1,explain:"看似 nghĩa là nhìn có vẻ/thoạt trông như."}
        ]
    }
};
if (window.CEFR_ENGLISH_BANK) DATA_BANK.english = window.CEFR_ENGLISH_BANK;
if (window.GRADE5_BANK) { DATA_BANK.grade5_math=window.GRADE5_BANK.grade5_math; DATA_BANK.grade5_viet=window.GRADE5_BANK.grade5_viet; DATA_BANK.grade5_eng=window.GRADE5_BANK.grade5_eng; }

let STUDENTS = [
    { id: 'user', name: 'Học viên 01', avatar: '🧑‍🎓', score: 0, isUser: true, answered: false, lastAns: '' },
    { id: 'bot1', name: 'Điệp viên 009 (AI)', avatar: '👱‍♀️', score: 15, isUser: false, answered: false, lastAns: '' },
    { id: 'bot2', name: 'Con Ong Vui Vẻ', avatar: '👧', score: 10, isUser: false, answered: false, lastAns: '' },
    { id: 'bot3', name: 'Nói Ít Làm Liều', avatar: '🧑‍🎨', score: 10, isUser: false, answered: false, lastAns: '' },
    { id: 'bot4', name: 'Cherry Ổi', avatar: '🧒', score: 5, isUser: false, answered: false, lastAns: '' },
    { id: 'bot5', name: 'Bánh Sinh Nhật', avatar: '👩‍💻', score: 5, isUser: false, answered: false, lastAns: '' }
];

let appMode = 'english';
let currentSubCategory = 'A1';
let questionIndex = 0;
let currentItem = null;
let currentAnswerChars = [];
let scrambledChars = [];
let timer = 20;
let timerInterval = null;
let userStreak = 0;
let roundSolvedByUser = false;
let isPaused = false;
let isSolo = true;

const englishDeckState = {};
const grade5DeckState = {};
function getGrade5RoundItem(mode, sub){
    const groups=DATA_BANK[mode]||{}; const list=groups[sub]||[]; if(!list.length)return null;
    const key=mode+':'+sub; let state=grade5DeckState[key];
    if(!state || state.index>=state.order.length){
        const prev=state&&state.last; let order=[...Array(list.length).keys()];
        for(let i=order.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[order[i],order[j]]=[order[j],order[i]];}
        if(prev!=null && order.length>1 && order[0]===prev){[order[0],order[1]]=[order[1],order[0]];}
        state=grade5DeckState[key]={order,index:0,last:prev};
    }
    const idx=state.order[state.index++]; state.last=idx; return list[idx];
}
function getEnglishRoundItem(sub){
    const list = DATA_BANK.english[sub] || [];
    if(!list.length) return null;
    let state = englishDeckState[sub];
    if(!state || state.index >= state.order.length){
        const previousLast = state ? state.last : undefined;
        const order = list.map((_,i)=>i);
        for(let i=order.length-1;i>0;i--){
            const j=Math.floor(Math.random()*(i+1));
            [order[i],order[j]]=[order[j],order[i]];
        }
        if(previousLast!==undefined && order.length>1 && order[0]===previousLast){
            [order[0],order[1]]=[order[1],order[0]];
        }
        state = englishDeckState[sub] = {order,index:0,last:previousLast};
    }
    const idx = state.order[state.index++];
    state.last = idx;
    return list[idx];
}

let peer = null;
let conn = null;
let isHost = false;
let myRoomCode = '';

function startSoloMode() {
    const name = document.getElementById('userNameInput').value.trim() || 'Học viên 01';
    STUDENTS[0].name = name;
    if(typeof saveStudentProfile==='function') saveStudentProfile({name});
    isSolo = true;
    document.getElementById('roomStatusText').innerText = "Chế độ: Học 1 mình cùng AI";
    document.getElementById('setupModal').classList.remove('open');
    renderClassroom();
    loadQuestion();
    teacherSpeak(`Chào mừng ${name} đến với lớp học thông minh! Cùng bắt đầu nhé.`);
}

function openMultiplayerSetup() {
    isHost = true;
    isSolo = false;
    const name = document.getElementById('userNameInput').value.trim() || 'Chủ Phòng';
    STUDENTS[0].name = name;
    
    myRoomCode = Math.floor(1000 + Math.random() * 9000).toString();
    const box = document.getElementById('multiplayerBox');
    box.style.display = 'flex';
    document.getElementById('roomCodeInfo').innerText = `Mã phòng của bạn: #${myRoomCode} (Đang kết nối Cloud Server...)`;

    if (typeof Peer !== 'undefined') {
        if (peer) peer.destroy();
        // Cấu hình PeerJS sử dụng cloud server công cộng ổn định miễn phí
        peer = new Peer('ai-class-room-' + myRoomCode, {
            host: '0.peerjs.com',
            port: 443,
            secure: true,
            path: '/'
        });
        peer.on('open', (id) => {
            document.getElementById('roomCodeInfo').innerText = `✅ Phòng #${myRoomCode} đã sẵn sàng nhận khách!`;
        });
        peer.on('connection', (incomingConn) => {
            conn = incomingConn;
            setupConnectionEvents();
            document.getElementById('roomStatusText').innerText = `🟢 Đã kết nối với khách!`;
            document.getElementById('setupModal').classList.remove('open');
            renderClassroom();
            loadQuestion();
            teacherSpeak("Khách đã vào phòng! Chúng ta cùng học nhé!");
            syncStateToPeer();
        });
        peer.on('error', (err) => {
            document.getElementById('roomCodeInfo').innerText = `Lỗi P2P: ${err.type}. Hãy thử lại!`;
        });
    }
}

function joinRoom() {
    const code = document.getElementById('joinCodeInput').value.trim();
    const name = document.getElementById('userNameInput').value.trim() || 'Học Viên Khách';
    if (code.length !== 4) { alert('Vui lòng nhập mã phòng 4 chữ số hợp lệ!'); return; }
    
    isHost = false;
    isSolo = false;
    STUDENTS[0].name = name;
    document.getElementById('roomStatusText').innerText = `Đang kết nối phòng #${code}...`;

    if (typeof Peer !== 'undefined') {
        if (peer) peer.destroy();
        peer = new Peer({
            host: '0.peerjs.com',
            port: 443,
            secure: true,
            path: '/'
        });
        peer.on('open', () => {
            conn = peer.connect('ai-class-room-' + code);
            setupConnectionEvents();
        });
        peer.on('error', (err) => {
            alert('Không tìm thấy phòng #' + code + '. Hãy đảm bảo Chủ Phòng đã tạo trước!');
            document.getElementById('roomStatusText').innerText = 'Kết nối thất bại';
        });
    }
}

function setupConnectionEvents() {
    if (!conn) return;
    conn.on('open', () => {
        document.getElementById('roomStatusText').innerText = `🟢 Đã kết nối 1v1 thành công!`;
        document.getElementById('setupModal').classList.remove('open');
        renderClassroom();
        if (!isHost) {
            conn.send({ type: 'REQUEST_SYNC', name: STUDENTS[0].name });
        }
    });
    conn.on('data', (packet) => {
        handlePeerPacket(packet);
    });
    conn.on('close', () => {
        document.getElementById('roomStatusText').innerText = `⚠️ Mất kết nối 1v1`;
        addFeedMessage('Hệ thống', 'Đối thủ đã ngắt kết nối.');
    });
}

function sendPacket(pkt) {
    if (conn && conn.open) {
        conn.send(pkt);
    }
}

function handlePeerPacket(d) {
    if (!d) return;
    if (d.type === 'SYNC_STATE') {
        appMode = d.appMode || 'english';
        currentSubCategory = normalizeLearningSub(appMode, d.currentSubCategory);
        questionIndex = d.questionIndex;
        toggleLangModelUI();
        loadQuestion(true);
    } else if (d.type === 'REQUEST_SYNC' && isHost) {
        let peerStudent = STUDENTS.find(s => s.id === 'peer');
        if (!peerStudent) {
            peerStudent = { id: 'peer', name: d.name, avatar: '👩‍🎓', score: 0, isFriend: true, answered: false, lastAns: '' };
            STUDENTS.push(peerStudent);
        } else {
            peerStudent.name = d.name;
        }
        renderClassroom();
        syncStateToPeer();
    } else if (d.type === 'USER_SCORE') {
        const peerStudent = STUDENTS.find(s => s.id === 'peer');
        if (peerStudent) {
            peerStudent.score = d.score;
            peerStudent.answered = true;
            peerStudent.lastAns = d.lastAns;
        }
        renderClassroom();
        addFeedMessage(d.name, `(+${d.bonus}đ)`, true);
    }
}

function syncStateToPeer() {
    if (isHost) {
        sendPacket({ type: 'SYNC_STATE', appMode, currentSubCategory, questionIndex });
    }
}

function renderClassroom() {
    const grid = document.getElementById('classroomGrid');
    const sorted = [...STUDENTS].sort((a, b) => b.score - a.score);
    grid.innerHTML = sorted.map((st, idx) => `
        <div class="student-desk ${st.isUser ? 'is-user' : ''} ${st.isFriend ? 'is-friend' : ''} ${st.answered ? 'answered' : ''}">
            <div class="desk-tag">
                <span class="rank-num">#${idx + 1}</span>
                <span class="student-pts">✓ ${st.score}đ</span>
            </div>
            <div class="student-name">${st.name}</div>
            <div class="avatar-box">
                <span>${st.avatar}</span>
                <span class="hand-raise">✋</span>
                <div class="answer-pop ${st.lastAns ? 'show' : ''}">${st.lastAns}</div>
            </div>
            <div class="wood-table"></div>
        </div>
    `).join('');
}

function addFeedMessage(sender, msg, highlight = false) {
    const feed = document.getElementById('liveFeed');
    const div = document.createElement('div');
    div.className = 'feed-msg';
    div.style.borderLeft = highlight ? '3px solid #06d6a0' : 'none';
    div.innerHTML = `<b>${sender}:</b> ${msg}`;
    feed.prepend(div);
}

function normalizeLearningSub(mode, sub) {
    if(mode==='english') return ['A1','A2','B1','B2','C1'].includes(String(sub)) ? String(sub) : 'A1';
    if(mode==='grade5_math') return (window.GRADE5_META&&GRADE5_META.grade5_math[sub]) ? sub : 'M1';
    if(mode==='grade5_viet') return (window.GRADE5_META&&GRADE5_META.grade5_viet[sub]) ? sub : 'V1';
    if(mode==='grade5_eng') return (window.GRADE5_META&&GRADE5_META.grade5_eng[sub]) ? sub : 'E1';
    if(mode==='chinese_hsk') { const n=Number(sub); return n>=1&&n<=6?n:1; }
    return sub;
}

function closeProgramModal(){ document.getElementById('langModal')?.classList.remove('open'); }
function showProgramModal(){ if(window.LearningHub) LearningHub.close(); document.getElementById('langModal')?.classList.add('open'); }
function openLearningHub(tab='path'){ closeProgramModal(); if(window.LearningHub) LearningHub.open(tab); }

function changeModeAndSync(mode, sub, source='program') {
    setAppMode(mode, sub, source);
    if (isHost) syncStateToPeer();
}

function setAppMode(mode, sub, source='system') {
    appMode = mode;
    currentSubCategory = normalizeLearningSub(mode, sub);
    questionIndex = 0;
    toggleLangModelUI();
    if(source==='program') closeProgramModal();
    if(source==='hub' && window.LearningHub) LearningHub.close();
    loadQuestion();
}

function switchTopic(sub) {
    const prev=currentSubCategory;
    currentSubCategory = normalizeLearningSub(appMode, sub);
    questionIndex = 0;
    if(prev!==currentSubCategory){ delete englishDeckState[currentSubCategory]; delete grade5DeckState[appMode+':'+currentSubCategory]; }
    toggleLangModelUI();
    loadQuestion();
    if (isHost) syncStateToPeer();
}

function toggleLangModelUI() {
    window.appMode = appMode;
    window.currentSubCategory = currentSubCategory;
    const topicBar = document.getElementById('topicBar');
    const slots = document.getElementById('wordSlots');
    const tiles = document.getElementById('scrambleTiles');
    const quizBox = document.getElementById('quizBoardBox');
    const headerTitle = document.getElementById('appHeaderTitle');

    if (appMode === 'english') {
        headerTitle.innerText = `🇬🇧 ENGLISH CEFR • ${currentSubCategory}`;
        topicBar.style.display = 'flex'; slots.style.display = 'flex'; tiles.style.display = 'flex';
        quizBox.classList.remove('active');
        topicBar.innerHTML = ['A1','A2','B1','B2','C1'].map(l=>`<button class="topic-btn ${currentSubCategory===l?'active':''}" onclick="switchTopic('${l}')">${l}</button>`).join('') + `<span class="cefr-course-note">CEFR • Communicative • Task-based</span>`;
    } else {
        slots.style.display = 'none'; tiles.style.display = 'none'; quizBox.classList.add('active');
        const isG5=['grade5_math','grade5_viet','grade5_eng'].includes(appMode);
        if(isG5 && window.GRADE5_META){
            topicBar.style.display='flex'; const meta=GRADE5_META[appMode]||{};
            topicBar.innerHTML=Object.entries(meta).map(([k,label])=>`<button class="topic-btn ${currentSubCategory===k?'active':''}" onclick="switchTopic('${k}')">${label}</button>`).join('');
        } else topicBar.style.display='none';
        if (appMode === 'grade5_math') headerTitle.innerText = "📐 TOÁN LỚP 5 • NGÂN HÀNG 96 BÀI";
        if (appMode === 'grade5_viet') headerTitle.innerText = "📖 TIẾNG VIỆT LỚP 5 • NGÂN HÀNG 96 BÀI";
        if (appMode === 'grade5_eng') headerTitle.innerText = "🌟 TIẾNG ANH LỚP 5 • 20 UNITS / 120 BÀI";
        if (appMode === 'chinese_hsk') headerTitle.innerText = `🇨🇳 TIẾNG TRUNG HSK ${currentSubCategory}`;
    }
    const mathBtn = document.getElementById('mathPadLaunch');
    if (mathBtn) mathBtn.style.display = appMode === 'grade5_math' ? 'block' : 'none';
}

function loadQuestionLocal(syncFromRemote = false) {
    clearInterval(timerInterval);
    // Defensive state/UI sync: active tab must always reflect the actual learning state.
    if(typeof toggleLangModelUI==='function') toggleLangModelUI();
    roundSolvedByUser = false;
    const isGrade5=['grade5_math','grade5_viet','grade5_eng'].includes(appMode);
    let list = appMode === 'english' ? DATA_BANK.english[currentSubCategory] : (appMode === 'chinese_hsk' ? DATA_BANK.chinese_hsk[currentSubCategory] : (isGrade5 ? (DATA_BANK[appMode][currentSubCategory]||[]) : DATA_BANK[appMode]));
    currentItem = appMode === 'english' ? getEnglishRoundItem(currentSubCategory) : (isGrade5 ? getGrade5RoundItem(appMode,currentSubCategory) : list[questionIndex % list.length]);
    if(!currentItem){ console.error('Không có dữ liệu bài học', appMode,currentSubCategory); return; }
    currentAnswerChars = [];

    STUDENTS.forEach(s => { s.answered = false; s.lastAns = ''; });
    renderClassroom();

    if (appMode === 'english') {
        document.getElementById('qMeta').innerText = `Câu ${questionIndex + 1} • ${currentItem.type} • ${currentItem.activity||''}`;
        document.getElementById('situationTag').innerText = currentItem.situation || currentItem.type;
        if(currentItem.kind === 'mcq'){
            document.getElementById('wordSlots').style.display='none';
            document.getElementById('scrambleTiles').style.display='none';
            document.getElementById('quizBoardBox').classList.add('active');
            document.getElementById('viPrompt').innerText = currentItem.prompt;
            document.getElementById('phoneticHint').innerText = `🎯 ${currentItem.canDo} • ${currentItem.grammar}`;
            document.getElementById('grade5QText').innerText = currentItem.prompt;
            document.getElementById('grade5OptsGrid').innerHTML = currentItem.options.map((o,i)=>`<button class="mini-opt" onclick="chooseEnglishCefrOption(${i},this)">${String.fromCharCode(65+i)}. ${o}</button>`).join('');
            teacherSpeak(currentItem.speak || currentItem.prompt, 'en-US');
        } else {
            document.getElementById('quizBoardBox').classList.remove('active');
            document.getElementById('wordSlots').style.display='flex';
            document.getElementById('scrambleTiles').style.display='flex';
            document.getElementById('viPrompt').innerText = currentItem.vi;
            document.getElementById('phoneticHint').innerText = `${currentItem.ipa} • ${currentItem.hook} • Nghe 🔊`;
            scrambledChars = currentItem.word.split('').map((ch, idx) => ({ char: ch, id: idx, used: false })).sort(() => Math.random() - 0.5);
            renderBoardSlots(); renderScrambleTiles();
            teacherSpeak(`Câu ${questionIndex + 1}: ${currentItem.vi} tiếng Anh là gì?`);
        }
    } else {
        document.getElementById('qMeta').innerText = appMode === 'chinese_hsk' ? `Bài ${questionIndex + 1} • HSK ${currentSubCategory}` : `Bài ${questionIndex + 1} • Lớp 5 • ${currentItem.activity||'Luyện tập'}`;
        document.getElementById('situationTag').innerText = currentItem.topic;
        document.getElementById('viPrompt').innerHTML = appMode === 'chinese_hsk' ? `<span class="hanzi-main">${currentItem.hanzi}</span><br><span class="pinyin-line">${currentItem.pinyin}</span><br><span class="vn-line">${currentItem.vn}</span>` : currentItem.summary;
        document.getElementById('phoneticHint').innerText = appMode === 'chinese_hsk' ? currentItem.summary : "Chọn đáp án đúng bên dưới";
        document.getElementById('grade5QText').innerText = currentItem.question;
        const gGrid = document.getElementById('grade5OptsGrid');
        gGrid.innerHTML = currentItem.options.map((opt, idx) => `
            <button class="mini-opt" onclick="checkGrade5Answer(${idx}, ${currentItem.correct})">
                ${String.fromCharCode(65 + idx)}. ${opt}
            </button>
        `).join('');
        if(appMode==='chinese_hsk' && window.MultiVoiceManager){ const bubble=document.getElementById('teacherBubble'); if(bubble) bubble.innerHTML=`${currentItem.hanzi} • ${currentItem.pinyin}<br>${currentItem.vn}<br>${currentItem.question}`; MultiVoiceManager.speakSequence([{text:currentItem.hanzi,lang:'zh-CN',rate:.82},{text:`${currentItem.vn}. ${currentItem.question}`,lang:'vi-VN',rate:1.0}]); } else teacherSpeak(currentItem.topic + '. ' + currentItem.question);
    }

    timer = 20;
    document.getElementById('timerDisplay').innerText = timer;
    if (!isSolo && !isHost) return;
    timerInterval = setInterval(() => {
        if (isPaused) return;
        timer--;
        document.getElementById('timerDisplay').innerText = timer;
        if (!isSolo && isHost && typeof publishRoomState === 'function') publishRoomState();
        if (timer <= 0) {
            clearInterval(timerInterval);
            if (appMode === 'english') revealAndNext();
        }
    }, 1000);
}

function renderBoardSlots() {
    const container = document.getElementById('wordSlots');
    container.innerHTML = currentItem.word.split('').map((_, i) => {
        const item = currentAnswerChars[i];
        return `<div class="slot-box ${item ? 'filled' : ''}" onclick="removeCharAt(${i})">${item ? item.char : ''}</div>`;
    }).join('');
}

function renderScrambleTiles() {
    const container = document.getElementById('scrambleTiles');
    container.innerHTML = scrambledChars.map((item, idx) => `
        <button class="tile-btn ${item.used ? 'used' : ''}" onclick="selectTile(${idx})">${item.char}</button>
    `).join('');
}

function selectTile(idx) {
    if (roundSolvedByUser || isPaused) return;
    const item = scrambledChars[idx];
    if (item.used || currentAnswerChars.length >= currentItem.word.length) return;
    item.used = true; currentAnswerChars.push(item);
    renderBoardSlots(); renderScrambleTiles();
    if (currentAnswerChars.length === currentItem.word.length) {
        verifyUserAnswer(currentAnswerChars.map(c => c.char).join(''), 'ghép chữ');
    }
}

function removeCharAt(slotIdx) {
    if (roundSolvedByUser || isPaused || !currentAnswerChars[slotIdx]) return;
    const removed = currentAnswerChars.splice(slotIdx, 1)[0];
    removed.used = false;
    renderBoardSlots(); renderScrambleTiles();
}

function checkGrade5Answer(selected, correct) {
    if (roundSolvedByUser || isPaused) return;
    const opts = document.querySelectorAll('.mini-opt');
    opts.forEach((o, i) => {
        if (i === correct) o.classList.add('correct');
        else if (i === selected) o.classList.add('wrong');
        o.disabled = true;
    });
    if (selected === correct) {
        scorePoints('Đúng bài tập', 10);
        teacherSpeak("Chính xác! " + currentItem.explain);
    } else {
        if(window.LearningHub)LearningHub.recordMistake(currentItem, selected);
        teacherSpeak("Chưa chính xác. " + currentItem.explain);
    }
}

function verifyUserAnswer(rawInput, method) {
    const cleaned = rawInput.trim().toUpperCase().replace(/[^A-Z]/g, '');
    if (!cleaned || roundSolvedByUser || isPaused) return;
    if (cleaned === currentItem.word) {
        scorePoints(method, Math.max(5, timer));
    } else {
        if(window.LearningHub)LearningHub.recordMistake(currentItem,rawInput);
        teacherSpeak(`Cô nghe được "${rawInput}". Xem lại phiên âm ${currentItem.ipa} nhé!`);
        currentAnswerChars.forEach(c => c.used = false);
        currentAnswerChars = [];
        renderBoardSlots(); renderScrambleTiles();
    }
}

function scorePoints(method, bonus) {
    roundSolvedByUser = true;
    userStreak++;
    const userObj = STUDENTS[0];
    userObj.score += bonus; userObj.answered = true;
    userObj.lastAns = appMode === 'english' ? currentItem.word.toLowerCase() : 'Đúng';
    document.getElementById('streakText').innerText = `🔥 Chuỗi: ${userStreak} | ${userObj.score}đ`;
    renderClassroom();
    addFeedMessage(userObj.name, `(+${bonus}đ qua ${method})`, true);
    teacherSpeak(`Giỏi lắm ${userObj.name}! Trả lời xuất sắc!`);
    
    if (!isSolo) {
        sendPacket({ type: 'USER_SCORE', name: userObj.name, score: userObj.score, bonus, lastAns: userObj.lastAns });
    }

    clearInterval(timerInterval);
    setTimeout(() => { questionIndex++; loadQuestion(); if (isHost) syncStateToPeer(); }, 3500);
}

function chooseEnglishCefrOption(index, btn){
    if(isPaused || roundSolvedByUser || !currentItem || currentItem.kind!=='mcq') return;
    const buttons=[...document.querySelectorAll('#grade5OptsGrid .mini-opt')];
    buttons.forEach(b=>b.disabled=true);
    if(index===currentItem.correct){
        btn.classList.add('correct');
        teacherSpeak('Great job! ' + currentItem.explain, 'en-US');
        scorePoints('CEFR', 10);
    } else {
        if(window.LearningHub)LearningHub.recordMistake(currentItem,index);
        btn.classList.add('wrong');
        const right=buttons[currentItem.correct]; if(right) right.classList.add('correct');
        teacherSpeak('Not quite. ' + currentItem.explain, 'en-US');
        setTimeout(()=>{buttons.forEach(b=>b.disabled=false);},1200);
    }
}

function nextQuestionManually() {
    questionIndex++;
    loadQuestion();
    if (isHost) syncStateToPeer();
    teacherSpeak("Chuyển sang bài tiếp theo nhé!");
}

function submitTypedAnswer() {
    const input = document.getElementById('answerInput');
    if (!input.value.trim() || isPaused) return;
    verifyUserAnswer(input.value, 'nhắn tin');
    input.value = '';
}

function togglePauseGame() {
    isPaused = !isPaused;
    const btn = document.getElementById('pauseBtn');
    btn.innerText = isPaused ? "▶️ Tiếp Tục" : "⏸️ Tạm Dừng";
    teacherSpeak(isPaused ? "Lớp học đã tạm dừng." : "Lớp học tiếp tục nhé!");
}

function openLangModal() { showProgramModal(); }
let teacherVoiceEnabled = true, teacherSubtitlesEnabled = true;
function toggleTeacherSubtitles(){teacherSubtitlesEnabled=!teacherSubtitlesEnabled;document.getElementById('teacherCaptionPanel').classList.toggle('hidden',!teacherSubtitlesEnabled);document.getElementById('subtitleToggleBtn').innerText=teacherSubtitlesEnabled?'💬':'🚫';}
function toggleTeacherVoice(){teacherVoiceEnabled=!teacherVoiceEnabled;if(!teacherVoiceEnabled&&'speechSynthesis' in window){window.speechSynthesis.cancel();setTeacherSpeaking(false);}document.getElementById('voiceToggleBtn').innerText=teacherVoiceEnabled?'🔊':'🔇';}
function toggleTeacherMinimize(){const el=document.getElementById('teacherContainer');el.classList.toggle('minimized');document.getElementById('teacherMinBtn').innerText=el.classList.contains('minimized')?'+':'−';}
function setTeacherSpeaking(isSpeaking){
    const avatar=document.getElementById('teacherAvatarWrap') || document.getElementById('teacherSvg');
    const photo=document.getElementById('teacherPhoto');
    if(avatar) avatar.classList.toggle('speaking', !!isSpeaking);
    if(photo && photo.style.display!=='none') {
        const idle=photo.dataset.idleSrc || 'teacher-ai-idle.png';
        const speaking=photo.dataset.speakingSrc || 'teacher-ai-speaking.gif';
        const target=isSpeaking?speaking:idle;
        if(!photo.src.endsWith(target)) photo.src=target;
    }
}

function teacherSpeak(text, langOverride) {
    if (isPaused) return;
    const bubble=document.getElementById('teacherBubble'); if(bubble){bubble.innerHTML=text;bubble.scrollTop=bubble.scrollHeight;}
    if (!teacherVoiceEnabled || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const lang = langOverride || (appMode === 'chinese_hsk' ? 'zh-CN' : ((appMode === 'english' || appMode === 'grade5_eng') ? 'en-US' : 'vi-VN'));
    const rate = lang.startsWith('zh') ? .90 : (lang.startsWith('en') ? .96 : 1.0);
    const avatar=document.getElementById('teacherAvatarWrap') || document.getElementById('teacherSvg');
    const onstart=()=>setTeacherSpeaking(true);
    const onend=()=>setTeacherSpeaking(false);
    if (window.MultiVoiceManager) MultiVoiceManager.speak(text,{lang,rate,onstart,onend,onerror:onend});
    else {
        const utter = new SpeechSynthesisUtterance(text.replace(/<[^>]*>?/gm, ''));
        utter.lang=lang; utter.rate=rate; utter.onstart=onstart; utter.onend=onend; utter.onerror=onend;
        window.speechSynthesis.speak(utter);
    }
}
function speakCurrentInfo() {
    if (!currentItem) return;
    const avatar=document.getElementById('teacherAvatarWrap') || document.getElementById('teacherSvg');
    const onstart=()=>setTeacherSpeaking(true);
    const onend=()=>setTeacherSpeaking(false);
    if (window.MultiVoiceManager && teacherVoiceEnabled) {
        if (appMode === 'english') {
            const bubble=document.getElementById('teacherBubble'); if(bubble)bubble.innerHTML=`${currentItem.word} — ${currentItem.vi}`;
            return MultiVoiceManager.speakSequence([
                {text:currentItem.word,lang:'en-US',rate:.92},
                {text:`Nghĩa tiếng Việt: ${currentItem.vi}`,lang:'vi-VN',rate:1.0}
            ],{onstart,onend,onerror:onend});
        }
        if (appMode === 'chinese_hsk') {
            const bubble=document.getElementById('teacherBubble'); if(bubble)bubble.innerHTML=`${currentItem.hanzi} • ${currentItem.pinyin} — ${currentItem.vn}`;
            return MultiVoiceManager.speakSequence([
                {text:currentItem.hanzi,lang:'zh-CN',rate:.82},
                {text:`Nghĩa tiếng Việt: ${currentItem.vn}`,lang:'vi-VN',rate:1.0}
            ],{onstart,onend,onerror:onend});
        }
    }
    teacherSpeak(appMode === 'english' ? currentItem.word : (appMode === 'chinese_hsk' ? currentItem.hanzi : currentItem.topic + '. ' + currentItem.summary));
}
function giveSmartHint() {
    if (!currentItem) return;
    teacherSpeak(appMode === 'english' ? `Mẹo nhớ: ${currentItem.hook}` : (appMode === 'chinese_hsk' ? currentItem.summary : 'Hãy đọc kỹ phần tóm tắt lý thuyết trên bảng nhé!'));
}
function revealAndNext() {
    if (appMode === 'english') {
        currentAnswerChars = currentItem.word.split('').map((c, i) => ({ char: c, id: i }));
        renderBoardSlots();
        teacherSpeak(`Hết giờ! Đáp án là ${currentItem.word}.`);
    }
    setTimeout(() => { questionIndex++; loadQuestion(); if (isHost) syncStateToPeer(); }, 3500);
}
function startSmartVoiceInput() {
    if (isPaused) return;
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { alert("Trình duyệt không hỗ trợ nhận diện giọng nói!"); return; }
    const rec = new SpeechRecognition();
    rec.lang = appMode === 'chinese_hsk' ? 'zh-CN' : ((appMode === 'english' || appMode === 'grade5_eng') ? 'en-US' : 'vi-VN');
    document.getElementById('micBtn').classList.add('listening');
    teacherSpeak("Cô đang nghe em đọc...");
    rec.onresult = (e) => {
        const spoken = e.results[0][0].transcript;
        document.getElementById('micBtn').classList.remove('listening');
        if (appMode === 'english') verifyUserAnswer(spoken, 'phát âm AI');
        else document.getElementById('answerInput').value = spoken;
    };
    rec.onerror = () => document.getElementById('micBtn').classList.remove('listening');
    rec.onend = () => document.getElementById('micBtn').classList.remove('listening');
    rec.start();
}


/* ===== Mobile math handwriting pad ===== */
let mathPadPenMode='pen',mathDrawing=false,mathCtx=null,mathLast={x:0,y:0};
function toggleMathPad(show){
  if(appMode!=='grade5_math'&&show)return;
  const ov=document.getElementById('mathPadOverlay'); if(!ov)return; ov.classList.toggle('open',!!show);
  if(show){syncMathPadQuestion();requestAnimationFrame(initMathCanvas);}
}
function syncMathPadQuestion(){
  if(!currentItem)return; const q=document.getElementById('mathPadQuestion'),opts=document.getElementById('mathPadOptions');
  if(q)q.innerText=currentItem.question||''; if(opts)opts.innerHTML=(currentItem.options||[]).map((x,i)=>`<button onclick="checkGrade5Answer(${i},${currentItem.correct})">${String.fromCharCode(65+i)}. ${x}</button>`).join('');
}
function initMathCanvas(){
  const c=document.getElementById('mathCanvas');if(!c)return; const r=c.getBoundingClientRect(),dpr=window.devicePixelRatio||1;
  c.width=Math.max(1,Math.floor(r.width*dpr));c.height=Math.max(1,Math.floor(r.height*dpr));mathCtx=c.getContext('2d');mathCtx.scale(dpr,dpr);mathCtx.lineCap='round';mathCtx.lineJoin='round';
  const pt=e=>{const rr=c.getBoundingClientRect();return{x:e.clientX-rr.left,y:e.clientY-rr.top}};
  const down=e=>{e.preventDefault();mathDrawing=true;mathLast=pt(e)}; const move=e=>{if(!mathDrawing)return;e.preventDefault();const p=pt(e);mathCtx.globalCompositeOperation=mathPadPenMode==='eraser'?'destination-out':'source-over';mathCtx.strokeStyle='#111827';mathCtx.lineWidth=mathPadPenMode==='eraser'?22:3;mathCtx.beginPath();mathCtx.moveTo(mathLast.x,mathLast.y);mathCtx.lineTo(p.x,p.y);mathCtx.stroke();mathLast=p}; const up=()=>{mathDrawing=false};
  c.onpointerdown=down;c.onpointermove=move;c.onpointerup=up;c.onpointercancel=up;c.onpointerleave=up;
}
function setPenMode(mode){mathPadPenMode=mode}
function clearMathCanvas(){const c=document.getElementById('mathCanvas');if(c&&mathCtx)mathCtx.clearRect(0,0,c.width,c.height)}
window.addEventListener('resize',()=>{if(document.getElementById('mathPadOverlay')?.classList.contains('open'))initMathCanvas()});
