(function(){
'use strict';
const KEY='smartLearningHubV1';
const today=()=>new Date().toISOString().slice(0,10);
const defaultState=()=>({xp:0,gems:0,streak:0,lastStudy:'',dailyGoal:50,dailyXP:0,dailyDate:today(),hearts:5,maxHearts:5,quests:{},mistakes:[],reviews:[],mastery:{},milestones:[],settings:{heartsEnabled:true}});
let S=load();
function load(){try{return Object.assign(defaultState(),JSON.parse(localStorage.getItem(KEY)||'{}'));}catch(e){return defaultState();}}
function save(){localStorage.setItem(KEY,JSON.stringify(S));renderMini();}
function resetDaily(){if(S.dailyDate!==today()){S.dailyDate=today();S.dailyXP=0;S.quests={};recoverHeart();}}
function recoverHeart(){S.hearts=Math.min(S.maxHearts,Math.max(1,S.hearts||0));}
function studyDay(){resetDaily();const d=today();if(S.lastStudy!==d){if(S.lastStudy){const a=new Date(S.lastStudy+'T00:00:00'),b=new Date(d+'T00:00:00');const diff=Math.round((b-a)/86400000);S.streak=diff===1?(S.streak||0)+1:1;}else S.streak=1;S.lastStudy=d;} }
function itemId(item){if(!item)return 'unknown';return [window.appMode||'mode',window.currentSubCategory||'',item.word||item.hanzi||item.question||item.prompt||'item'].join('|').slice(0,220);}
function labelFor(item){return item?.word||item?.hanzi||item?.question||item?.prompt||item?.vi||'Bài học';}
function recordSuccess(item,bonus,method){studyDay();const gain=Math.max(5,Number(bonus)||10);S.xp+=gain;S.dailyXP+=gain;S.gems+=Math.max(1,Math.floor(gain/10));const id=itemId(item);const m=S.mastery[id]||{ok:0,bad:0};m.ok++;m.last=Date.now();S.mastery[id]=m;S.reviews=S.reviews.filter(x=>x.id!==id);S.reviews.push({id,label:labelFor(item),mode:window.appMode,sub:window.currentSubCategory,due:Date.now()+nextInterval(m.ok),strength:m.ok});if(S.reviews.length>300)S.reviews=S.reviews.slice(-300);quest('lesson',1);quest(window.appMode==='chinese_hsk'?'chinese':'english',1);checkMilestones();save();}
function recordMistake(item,answer){studyDay();const id=itemId(item);const m=S.mastery[id]||{ok:0,bad:0};m.bad++;m.last=Date.now();S.mastery[id]=m;S.mistakes.unshift({id,label:labelFor(item),answer:String(answer||''),mode:window.appMode,sub:window.currentSubCategory,at:Date.now()});S.mistakes=S.mistakes.filter((x,i,a)=>i===a.findIndex(y=>y.id===x.id)).slice(0,100);S.reviews=S.reviews.filter(x=>x.id!==id);S.reviews.unshift({id,label:labelFor(item),mode:window.appMode,sub:window.currentSubCategory,due:Date.now()+5*60000,strength:0});if(S.settings.heartsEnabled)S.hearts=Math.max(0,S.hearts-1);quest('mistakeReview',0);save();}
function nextInterval(n){return [0,10*60000,86400000,3*86400000,7*86400000,14*86400000,30*86400000][Math.min(n,6)]||30*86400000;}
function quest(k,n){resetDaily();S.quests[k]=(S.quests[k]||0)+n;}
function checkMilestones(){const milestones=[[100,'🌟 100 XP'],[500,'🏅 500 XP'],[1000,'🏆 1000 XP'],[3000,'👑 3000 XP']];milestones.forEach(([v,t])=>{if(S.xp>=v&&!S.milestones.includes(t))S.milestones.push(t)});}
function getQuests(){resetDaily();return [
 {key:'xp',icon:'⚡',name:'Kiếm 30 XP hôm nay',now:S.dailyXP,target:30},
 {key:'lesson',icon:'🎯',name:'Hoàn thành 5 bài',now:S.quests.lesson||0,target:5},
 {key:'lang',icon:'🗣️',name:'Luyện 3 hoạt động ngôn ngữ',now:(S.quests.english||0)+(S.quests.chinese||0),target:3}
];}
function renderMini(){const xp=document.getElementById('hubMiniXP'),st=document.getElementById('hubMiniStreak');if(xp)xp.textContent=`⚡ ${S.xp} XP`;if(st)st.textContent=`🔥 ${S.streak}`;}
function open(tab='path'){studyDay();save();if(typeof closeProgramModal==='function')closeProgramModal();const m=document.getElementById('learningHubModal');if(!m)return;m.classList.add('open');showTab(tab);renderAll();}
function close(){document.getElementById('learningHubModal')?.classList.remove('open');}
function showTab(tab){document.querySelectorAll('.hub-tab-btn').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));document.querySelectorAll('.hub-tab').forEach(x=>x.classList.toggle('active',x.id==='hub-'+tab));}
function renderAll(){renderPath();renderPractice();renderQuests();renderProfile();}
function renderPath(){const box=document.getElementById('hubPathBody');if(!box)return;const eng=['A1','A2','B1','B2','C1'];const zh=[1,2,3,4,5,6];box.innerHTML=`<div class="hub-section"><h3>🇬🇧 English CEFR Path</h3><p>Bài ngắn theo lộ trình: từ vựng → nghe/nói → hội thoại → grammar → task.</p><div class="hub-path">${eng.map((l,i)=>node('english',l,`${l}`,`${i*20+1}–${(i+1)*20}`)).join('')}</div></div><div class="hub-section"><h3>🇨🇳 Chinese HSK Path</h3><p>HSK → từ vựng → thanh điệu → nét chữ → hội thoại → story → review.</p><div class="hub-path">${zh.map((l,i)=>node('chinese_hsk',l,`HSK ${l}`,`${i*15+1}–${(i+1)*15}`)).join('')}</div></div>`;}
function node(mode,sub,title,range){return `<button class="hub-node" onclick="LearningHub.startPath('${mode}','${sub}')"><span>⭐</span><b>${title}</b><small>Unit ${range}</small></button>`;}
function renderPractice(){const box=document.getElementById('hubPracticeBody');if(!box)return;const due=S.reviews.filter(x=>x.due<=Date.now()).length;box.innerHTML=`<div class="practice-grid">
${card('🧠','Ôn cá nhân hóa',`${due} mục đến hạn`,`LearningHub.startReview()`)}
${card('❌','Ôn lỗi sai',`${S.mistakes.length} lỗi đã lưu`,`LearningHub.startMistakes()`)}
${card('🎧','Luyện nghe','Nghe rồi chọn/điền đáp án',`LearningHub.skill('listening')`)}
${card('🎤','Luyện nói','Đọc lại & hội thoại AI',`LearningHub.skill('speaking')`)}
${card('📖','Stories','Đọc/nghe truyện ngắn theo cấp',`LearningHub.skill('story')`)}
${card('🎭','Roleplay','Tình huống gọi món, hỏi đường, phỏng vấn…',`LearningHub.skill('roleplay')`)}
${card('✍️','Viết chữ Hán','Thứ tự nét + tự viết',`LearningHub.skill('stroke')`)}
${card('🎵','4 thanh điệu','Nghe, ghi âm và chấm pitch',`LearningHub.skill('tone')`)}
${card('🧩','Sơ đồ tư duy','Từ vựng + mẫu câu theo chủ đề',`LearningHub.skill('mindmap')`)}
${card('📚','Ngữ pháp Trung','Mẫu câu theo HSK',`LearningHub.skill('grammar')`)}
${card('🔤','Pinyin Chart','Âm đầu, vận mẫu, thanh điệu',`LearningHub.skill('pinyin')`)}
${card('🔎','Từ điển Hán–Việt','Tìm Hán tự, Pinyin hoặc nghĩa',`LearningHub.skill('dictionary')`)}
</div>`;}
function card(i,t,d,a){return `<button class="practice-card" onclick="${a}"><span>${i}</span><b>${t}</b><small>${d}</small></button>`;}
function renderQuests(){const box=document.getElementById('hubQuestBody');if(!box)return;box.innerHTML=`<div class="daily-goal"><b>🎯 Mục tiêu ngày</b><span>${S.dailyXP}/${S.dailyGoal} XP</span><div><i style="width:${Math.min(100,S.dailyXP/S.dailyGoal*100)}%"></i></div></div>${getQuests().map(q=>`<div class="quest-row"><span>${q.icon}</span><div><b>${q.name}</b><small>${Math.min(q.now,q.target)}/${q.target}</small><div class="quest-bar"><i style="width:${Math.min(100,q.now/q.target*100)}%"></i></div></div>${q.now>=q.target?'✅':''}</div>`).join('')}`;}
function renderProfile(){const box=document.getElementById('hubProfileBody');if(!box)return;box.innerHTML=`<div class="profile-stats"><div><b>${S.xp}</b><span>XP</span></div><div><b>${S.streak}</b><span>Ngày streak</span></div><div><b>${S.gems}</b><span>Gem</span></div><div><b>${S.hearts}</b><span>Tim</span></div></div><div class="hub-section"><h3>🏆 Thành tựu</h3><p>${S.milestones.length?S.milestones.join(' • '):'Học tiếp để mở khóa thành tựu.'}</p></div><div class="hub-section"><h3>📚 Tiến độ</h3><p>Đã lưu ${Object.keys(S.mastery).length} mục • ${S.reviews.length} mục trong lịch ôn • ${S.mistakes.length} lỗi cần xem lại.</p></div>`;}
function startPath(mode,sub){close();if(typeof changeModeAndSync==='function')changeModeAndSync(mode,mode==='chinese_hsk'?Number(sub):sub,'hub');}
function startReview(){const due=S.reviews.filter(x=>x.due<=Date.now()).sort((a,b)=>a.due-b.due)[0]||S.reviews[0];if(!due){alert('Chưa có mục đến hạn. Hãy học thêm vài bài trước.');return;}close();startPath(due.mode,due.sub);teacherSay(`Đây là bài ôn cá nhân hóa: ${due.label}`);}
function startMistakes(){const x=S.mistakes[0];if(!x){alert('Chưa có lỗi sai nào được lưu.');return;}close();startPath(x.mode,x.sub);teacherSay(`Cô sẽ cho em ôn lại lỗi: ${x.label}`);}
function teacherSay(t){setTimeout(()=>{if(typeof teacherSpeak==='function')teacherSpeak(t);},600);}
function skill(name){if(name==='tone'||name==='stroke'){close();if(typeof changeModeAndSync==='function')changeModeAndSync('chinese_hsk',1);setTimeout(()=>{if(window.HSKPro){HSKPro.open();HSKPro.showTab(name==='tone'?'tone':'stroke');}},350);return;}
 if(name==='speaking'){close();teacherSay('Chọn một câu hiện tại rồi bấm micro để luyện nói. Cô sẽ nghe và phản hồi.');return;}
 if(name==='listening'){close();teacherSay('Bật loa và nghe câu hiện tại trước khi nhìn đáp án.');return;}
 if(name==='story'){openStory();return;} if(name==='roleplay'){openRoleplay();return;} if(name==='mindmap'){openMindmap();return;} if(name==='grammar'){openGrammar();return;} if(name==='pinyin'){openPinyin();return;} if(name==='dictionary'){openDictionary();return;}}
const stories={english:[['At the café','Emma orders tea and a sandwich. The waiter asks, “Anything else?” Emma says, “That’s all, thank you.”','What did Emma order?'],['A missed bus','Tom missed his bus, so he asked a stranger for the next departure time.','Why did Tom ask a stranger?']],chinese:[['我的一天','我早上七点起床，八点去学校。下午我和朋友一起打篮球。','他几点起床？'],['在饭店','小王说：“请给我一碗面和一杯茶。”服务员说：“好的。”','小王点了什么？']]};
function openStory(){const zh=window.appMode==='chinese_hsk',a=zh?stories.chinese:stories.english,s=a[Math.floor(Math.random()*a.length)];document.getElementById('hubStoryTitle').textContent=`📖 ${s[0]}`;document.getElementById('hubStoryText').textContent=s[1];document.getElementById('hubStoryQuestion').textContent=s[2];document.getElementById('hubStoryModal').classList.add('open');if(window.MultiVoiceManager)MultiVoiceManager.speak(s[1],{lang:zh?'zh-CN':'en-US',rate:.88});quest('lesson',1);save();}
function closeStory(){document.getElementById('hubStoryModal')?.classList.remove('open');}
function openRoleplay(){const zh=window.appMode==='chinese_hsk';const scenarios=zh?[['🍜 Gọi món','你想在饭店点一碗面。请用中文说。'],['🛍️ Mua sắm','你想问价格并说“太贵了”。']]:[['☕ Café','Order a drink politely and ask for the price.'],['🗺️ Ask for directions','Ask someone how to get to the train station.'],['💼 Interview','Introduce yourself and describe one strength.']];const s=scenarios[Math.floor(Math.random()*scenarios.length)];document.getElementById('hubRoleTitle').textContent=`🎭 ${s[0]}`;document.getElementById('hubRolePrompt').textContent=s[1];document.getElementById('hubRoleModal').classList.add('open');}
function closeRoleplay(){document.getElementById('hubRoleModal')?.classList.remove('open');}
function roleSpeak(){closeRoleplay();teacherSay('Bấm nút micro ở thanh dưới và trả lời tình huống. Cô AI sẽ nghe em.');}
function openMindmap(){const zh=window.appMode==='chinese_hsk';const data=zh?['Chủ đề: Giao tiếp','你好 • xin chào','谢谢 • cảm ơn','请 • mời/xin','可以吗？ • có thể không?','我想… • tôi muốn…']:['Topic: Everyday communication','greet → hello / nice to meet you','ask → could you…?','clarify → do you mean…?','respond → sure / no problem','close → see you / take care'];document.getElementById('hubMindmapBody').innerHTML=data.map((x,i)=>`<div class="mind-node n${i}">${x}</div>`).join('');document.getElementById('hubMindmapModal').classList.add('open');}
function closeMindmap(){document.getElementById('hubMindmapModal')?.classList.remove('open');}

const grammarBank={
1:[['是…','A 是 B','我是一名学生。'],['有','S + 有 + O','我有一个朋友。'],['吗','Câu trần thuật + 吗？','你是老师吗？']],
2:[['因为…所以…','因为 A，所以 B','因为下雨，所以我不去。'],['正在','S + 正在 + V','我正在学习中文。'],['已经…了','S + 已经 + V + 了','我已经吃饭了。']],
3:[['如果…就…','如果 A，就 B','如果有时间，我就去。'],['虽然…但是…','虽然 A，但是 B','虽然很忙，但是他来了。'],['把','S + 把 + O + V','请把门打开。']],
4:[['不仅…而且…','不仅 A，而且 B','他不仅会说，还会写。'],['被','O + 被 + S + V','书被他拿走了。'],['越来越','越来越 + Adj','天气越来越冷。']],
5:[['既然…就…','既然 A，就 B','既然决定了，就坚持。'],['无论…都…','无论 A，都 B','无论多忙，我都学习。'],['甚至','…甚至…','他很忙，甚至没吃饭。']],
6:[['与其…不如…','与其 A，不如 B','与其抱怨，不如行动。'],['之所以…是因为…','之所以 A，是因为 B','他成功是因为坚持。'],['不但…反而…','不但 A，反而 B','不但没帮忙，反而添乱。']]
};
function openGrammar(){const level=Number(window.currentSubCategory)||1;const a=grammarBank[level]||grammarBank[1];document.getElementById('hubGrammarBody').innerHTML=a.map(x=>`<div class="grammar-card"><b>${x[0]}</b><span>${x[1]}</span><small>${x[2]}</small></div>`).join('');document.getElementById('hubGrammarModal').classList.add('open');}
function closeGrammar(){document.getElementById('hubGrammarModal')?.classList.remove('open');}
function openPinyin(){const rows=[['Âm đầu','b p m f • d t n l • g k h • j q x • zh ch sh r • z c s'],['Vận mẫu','a o e i u ü • ai ei ao ou • an en ang eng ong'],['Thanh 1','cao và ngang: mā'],['Thanh 2','đi lên: má'],['Thanh 3','hạ rồi nhấc: mǎ'],['Thanh 4','rơi nhanh: mà']];document.getElementById('hubPinyinBody').innerHTML=rows.map(x=>`<div class="pinyin-row"><b>${x[0]}</b><span>${x[1]}</span></div>`).join('');document.getElementById('hubPinyinModal').classList.add('open');}
function closePinyin(){document.getElementById('hubPinyinModal')?.classList.remove('open');}
function openDictionary(){document.getElementById('hubDictionaryModal').classList.add('open');dictionarySearch('');}
function closeDictionary(){document.getElementById('hubDictionaryModal')?.classList.remove('open');}
function dictionarySearch(q){q=String(q||'').trim().toLowerCase();const out=[];if(window.HSK_PRO_VOCAB){Object.entries(HSK_PRO_VOCAB).forEach(([l,a])=>a.forEach(x=>{if(!q||x[0].includes(q)||String(x[1]).toLowerCase().includes(q)||String(x[2]).toLowerCase().includes(q))out.push({l,x});}));}document.getElementById('hubDictionaryResults').innerHTML=out.slice(0,60).map(({l,x})=>`<button class="dict-row" onclick="LearningHub.sayChinese('${x[0].replace(/'/g,"\\'")}')"><b>${x[0]}</b><span>${x[1]}</span><small>${x[2]} • HSK ${l}</small>🔊</button>`).join('')||'<p>Không tìm thấy từ trong ngân hàng hiện tại.</p>';}
function sayChinese(t){if(window.MultiVoiceManager)MultiVoiceManager.speak(t,{lang:'zh-CN',rate:.8});}

function setDailyGoal(v){S.dailyGoal=Number(v)||50;save();renderQuests();}
function getState(){resetDaily();return S;}
document.addEventListener('DOMContentLoaded',()=>{studyDay();save();renderMini();});
window.LearningHub={open,close,showTab,renderAll,recordSuccess,recordMistake,startPath,startReview,startMistakes,skill,closeStory,closeRoleplay,roleSpeak,closeMindmap,closeGrammar,closePinyin,closeDictionary,dictionarySearch,sayChinese,setDailyGoal,getState};
})();
