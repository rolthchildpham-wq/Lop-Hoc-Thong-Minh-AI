(function(){
const V={
1:[
['你','nǐ','bạn',[3]],['好','hǎo','tốt',[3]],['我','wǒ','tôi',[3]],['是','shì','là',[4]],['不','bù','không',[4]],['人','rén','người',[2]],['中国','Zhōngguó','Trung Quốc',[1,2]],['学生','xuésheng','học sinh',[2,0]],['老师','lǎoshī','giáo viên',[3,1]],['朋友','péngyou','bạn bè',[2,0]],['谢谢','xièxie','cảm ơn',[4,0]],['再见','zàijiàn','tạm biệt',[4,4]],['今天','jīntiān','hôm nay',[1,1]],['明天','míngtiān','ngày mai',[2,1]],['喜欢','xǐhuan','thích',[3,0]]],
2:[
['每天','měitiān','mỗi ngày',[3,1]],['一起','yìqǐ','cùng nhau',[4,3]],['因为','yīnwèi','bởi vì',[1,4]],['所以','suǒyǐ','cho nên',[3,3]],['已经','yǐjīng','đã',[3,1]],['正在','zhèngzài','đang',[4,4]],['觉得','juéde','cảm thấy',[2,0]],['开始','kāishǐ','bắt đầu',[1,3]],['时间','shíjiān','thời gian',[2,1]],['事情','shìqing','sự việc',[4,0]],['可能','kěnéng','có thể',[3,2]],['非常','fēicháng','rất',[1,2]],['帮助','bāngzhù','giúp đỡ',[1,4]],['告诉','gàosu','nói cho biết',[4,0]],['问题','wèntí','vấn đề',[4,2]]],
3:[
['如果','rúguǒ','nếu',[2,3]],['但是','dànshì','nhưng',[4,4]],['比较','bǐjiào','tương đối/so sánh',[3,4]],['需要','xūyào','cần',[1,4]],['应该','yīnggāi','nên',[1,1]],['重要','zhòngyào','quan trọng',[4,4]],['环境','huánjìng','môi trường',[2,4]],['习惯','xíguàn','thói quen',[2,4]],['参加','cānjiā','tham gia',[1,1]],['完成','wánchéng','hoàn thành',[2,2]],['注意','zhùyì','chú ý',[4,4]],['最近','zuìjìn','gần đây',[4,4]],['终于','zhōngyú','cuối cùng',[1,2]],['选择','xuǎnzé','lựa chọn',[3,2]],['影响','yǐngxiǎng','ảnh hưởng',[3,3]]],
4:[
['虽然','suīrán','mặc dù',[1,2]],['但是','dànshì','nhưng',[4,4]],['不仅','bùjǐn','không chỉ',[4,3]],['而且','érqiě','mà còn',[2,3]],['理解','lǐjiě','hiểu',[3,3]],['解决','jiějué','giải quyết',[3,2]],['经验','jīngyàn','kinh nghiệm',[1,4]],['结果','jiéguǒ','kết quả',[2,3]],['条件','tiáojiàn','điều kiện',[2,4]],['改变','gǎibiàn','thay đổi',[3,4]],['发展','fāzhǎn','phát triển',[1,3]],['社会','shèhuì','xã hội',[4,4]],['关系','guānxì','quan hệ',[1,4]],['成功','chénggōng','thành công',[2,1]],['失败','shībài','thất bại',[1,4]]],
5:[
['坚持','jiānchí','kiên trì',[1,2]],['偶尔','ǒuěr','thỉnh thoảng',[3,3]],['深刻','shēnkè','sâu sắc',[1,4]],['印象','yìnxiàng','ấn tượng',[4,4]],['沟通','gōutōng','giao tiếp',[1,1]],['效率','xiàolǜ','hiệu suất',[4,4]],['责任','zérèn','trách nhiệm',[2,4]],['态度','tàidù','thái độ',[4,4]],['判断','pànduàn','phán đoán',[4,4]],['适应','shìyìng','thích nghi',[4,4]],['资源','zīyuán','tài nguyên',[1,2]],['实现','shíxiàn','thực hiện',[2,4]],['目标','mùbiāo','mục tiêu',[4,1]],['价值','jiàzhí','giá trị',[4,2]],['挑战','tiǎozhàn','thử thách',[3,4]]],
6:[
['与其','yǔqí','thay vì',[3,2]],['不如','bùrú','chi bằng',[4,2]],['抱怨','bàoyuàn','phàn nàn',[4,4]],['主动','zhǔdòng','chủ động',[3,4]],['寻找','xúnzhǎo','tìm kiếm',[2,3]],['合理','hélǐ','hợp lý',[2,3]],['实际上','shíjìshàng','trên thực tế',[2,4,4]],['推敲','tuīqiāo','xem xét kỹ',[1,1]],['趋势','qūshì','xu hướng',[1,4]],['现象','xiànxiàng','hiện tượng',[4,4]],['观点','guāndiǎn','quan điểm',[1,3]],['证据','zhèngjù','bằng chứng',[4,4]],['概念','gàiniàn','khái niệm',[4,4]],['策略','cèlüè','chiến lược',[4,4]],['综合','zōnghé','tổng hợp',[1,2]]]
};
const D={1:['谢谢','老师','今天'],2:['每天','开始','问题'],3:['如果','需要','重要'],4:['经验','结果','成功'],5:['坚持','效率','目标'],6:['观点','策略','综合']};
function other(level,idx,field){const a=V[level];return [1,2,3].map(k=>a[(idx+k*3)%a.length][field]);}
function activities(level){
 const a=V[level], out=[];
 a.forEach((x,i)=>{
  const [hanzi,pinyin,vn,tones]=x;
  out.push({topic:`HSK ${level} • Từ vựng`,hanzi,pinyin,vn,tones,summary:`${hanzi} (${pinyin}) = ${vn}.`,question:`“${hanzi}” có nghĩa là gì?`,options:[vn,...other(level,i,2)].sort(()=>Math.random()-.5),answerText:vn,type:'meaning'});
  out.push({topic:`HSK ${level} • Pinyin`,hanzi,pinyin,vn,tones,summary:`Nghe và đọc đúng Pinyin của ${hanzi}.`,question:`Pinyin đúng của “${hanzi}” là gì?`,options:[pinyin,...other(level,i,1)].sort(()=>Math.random()-.5),answerText:pinyin,type:'pinyin'});
  out.push({topic:`HSK ${level} • Nhận chữ`,hanzi,pinyin,vn,tones,summary:`Nhận diện Hán tự từ nghĩa tiếng Việt.`,question:`Chữ/cụm nào có nghĩa “${vn}”?`,options:[hanzi,...other(level,i,0)].sort(()=>Math.random()-.5),answerText:hanzi,type:'hanzi'});
  out.push({topic:`HSK ${level} • Nghe nói`,hanzi,pinyin,vn,tones,summary:`Bấm 🔊 nghe mẫu rồi luyện nói: ${pinyin}.`,question:`Nghe và chọn nghĩa đúng của “${hanzi}”.`,options:[vn,...other(level,i,2)].sort(()=>Math.random()-.5),answerText:vn,type:'listening'});
  out.push({topic:`HSK ${level} • Ôn tập`,hanzi,pinyin,vn,tones,summary:`Ôn đồng thời chữ Hán, Pinyin và nghĩa.`,question:`Cặp nào đúng?`,options:[`${hanzi} — ${pinyin} — ${vn}`,`${hanzi} — ${other(level,i,1)[0]} — ${vn}`,`${other(level,i,0)[1]} — ${pinyin} — ${vn}`,`${hanzi} — ${pinyin} — ${other(level,i,2)[2]}`].sort(()=>Math.random()-.5),answerText:`${hanzi} — ${pinyin} — ${vn}`,type:'review'});
 });
 return out.map((q,idx)=>({...q,correct:q.options.indexOf(q.answerText),explain:`Đúng: ${q.answerText}.`,bankId:`hsk${level}-${idx+1}`}));
}
window.HSK_PRO_VOCAB=V; window.HSK_PRO_BANK={};
for(let l=1;l<=6;l++) window.HSK_PRO_BANK[l]=activities(l);
window.HSK_PRO_TOTAL=Object.values(window.HSK_PRO_BANK).reduce((n,a)=>n+a.length,0);
})();
