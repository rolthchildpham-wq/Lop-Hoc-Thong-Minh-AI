
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyCjf-Y3jCRUuqN2pUTgOSIcV125zfQGol8",
  authDomain: "ai-learning-3339.firebaseapp.com",
  databaseURL: "https://ai-learning-3339-default-rtdb.firebaseio.com",
  projectId: "ai-learning-3339",
  storageBucket: "ai-learning-3339.firebasestorage.app",
  messagingSenderId: "246039255807",
  appId: "1:246039255807:web:a40e0758b8f2fa6c1d8aca",
  measurementId: "G-T145G239T2"
};
