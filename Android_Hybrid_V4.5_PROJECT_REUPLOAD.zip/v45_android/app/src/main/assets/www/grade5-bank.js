(function(){
function q(topic,summary,question,options,correct,explain,activity='Trắc nghiệm'){
  // Tương thích cả cú pháp đầy đủ và các mục cũ bị thiếu trường summary.
  // Cú pháp rút gọn cũ: q(topic, question, options[], correctIndex, explain[, activity])
  if(Array.isArray(question) && Number.isInteger(options) && typeof correct==='string'){
    const actualActivity = (typeof explain==='string' && explain) ? explain : activity;
    return {topic,summary:topic,question:summary,options:question,correct:options,explain:correct,activity:actualActivity||'Trắc nghiệm'};
  }
  return {topic,summary,question,options,correct,explain,activity};
}
const math={};
function addMath(key,title,items){ math[key]=items.map(x=>q(title,x[0],x[1],x[2],x[3],x[4],x[5]||'Luyện tập')); }
addMath('M1','Toán 5 • Số tự nhiên & giá trị chữ số',[
['Đọc, viết và xác định giá trị chữ số trong số tự nhiên.','Trong số 572 406, chữ số 7 có giá trị là:',['7','70','7 000','70 000'],4?3:3,'7 ở hàng chục nghìn nên có giá trị 70 000.'],
['So sánh số tự nhiên dựa vào số chữ số và từng hàng.','Số nào lớn nhất?',['395 820','395 802','359 820','395 280'],0,'So sánh từ hàng trăm nghìn xuống; 395 820 lớn nhất.'],
['Làm tròn số đến hàng nghìn.','Làm tròn 68 549 đến hàng nghìn được:',['68 000','69 000','68 500','70 000'],1,'549 ≥ 500 nên làm tròn lên 69 000.'],
['Dãy số tăng đều.','Số tiếp theo của dãy 120, 240, 360, 480 là:',['500','560','600','620'],2,'Mỗi số tăng 120.'],
['Phân tích số theo hàng.','400 000 + 30 000 + 2 000 + 50 + 6 bằng:',['432 056','432 506','430 256','432 560'],0,'Cộng các giá trị theo hàng được 432 056.'],
['Số chẵn và số lẻ.','Số nào là số lẻ?',['4 218','7 306','9 575','6 420'],2,'Số lẻ có chữ số tận cùng 1,3,5,7,9.'],
['Thứ tự thực hiện phép tính.','120 + 30 × 4 bằng:',['600','240','180','150'],1,'Nhân trước: 30×4=120; rồi 120+120=240.'],
['Ước lượng kết quả.','Ước lượng 4 982 + 3 041 gần nhất là:',['7 000','8 000','9 000','10 000'],1,'Làm tròn 5 000 + 3 000 ≈ 8 000.'],
['Tìm số chưa biết.','x + 2 450 = 7 000. x bằng:',['4 450','4 550','5 450','5 550'],1,'x=7 000−2 450=4 550.'],
['Bài toán thực tế về số tự nhiên.','Thư viện có 12 450 sách, nhập thêm 2 350 sách. Có tất cả:',['14 700','14 800','14 900','15 800'],1,'12 450 + 2 350 = 14 800.'],
['Chia có dư.','125 : 6 có thương và số dư là:',['20 dư 5','21 dư 1','19 dư 11','20 dư 6'],0,'6×20=120, còn dư 5.'],
['Nhân số tự nhiên.','245 × 30 bằng:',['7 250','7 350','7 450','73 500'],1,'245×3=735, thêm một chữ số 0 → 7 350.']
]);
addMath('M2','Toán 5 • Phân số & hỗn số',[
['Phân số biểu thị phần bằng nhau của một đơn vị.','Phân số nào bằng 1/2?',['2/3','3/6','4/6','5/8'],1,'3/6 rút gọn chia cả tử và mẫu cho 3 được 1/2.'],
['Rút gọn phân số.','Rút gọn 18/24 được:',['3/4','2/3','4/5','6/8'],0,'Chia cả tử và mẫu cho 6 được 3/4.'],
['Quy đồng mẫu số.','Mẫu chung nhỏ nhất của 1/3 và 1/4 là:',['7','12','16','24'],1,'BCNN của 3 và 4 là 12.'],
['So sánh phân số cùng mẫu.','Phân số lớn hơn là:',['3/7','5/7','Bằng nhau','Không so sánh được'],1,'Cùng mẫu 7, tử 5 lớn hơn 3.'],
['Cộng phân số cùng mẫu.','2/9 + 4/9 bằng:',['6/18','6/9','2/3','Cả B và C đúng'],3,'6/9 rút gọn thành 2/3.'],
['Trừ phân số khác mẫu.','3/4 − 1/2 bằng:',['1/4','2/4','1/2','1/8'],0,'1/2=2/4; 3/4−2/4=1/4.'],
['Nhân phân số.','2/3 × 3/5 bằng:',['6/15','2/5','5/6','Cả A và B đúng'],3,'6/15 rút gọn thành 2/5.'],
['Chia phân số.','3/4 : 2/5 bằng:',['6/20','15/8','8/15','5/6'],1,'3/4 × 5/2 = 15/8.'],
['Đổi hỗn số thành phân số.','2 và 3/7 bằng:',['17/7','14/7','13/7','10/7'],0,'2×7+3=17, giữ mẫu 7.'],
['Đổi phân số lớn hơn 1 thành hỗn số.','11/4 bằng:',['2 và 1/4','2 và 3/4','3 và 1/4','1 và 3/4'],1,'11:4=2 dư 3 → 2 và 3/4.'],
['Tìm phân số của một số.','3/5 của 40 là:',['15','20','24','25'],2,'40×3/5=24.'],
['Bài toán phân số.','Một lớp có 30 học sinh, 2/5 là nam. Có bao nhiêu bạn nam?',['10','12','15','18'],1,'30×2/5=12.']
]);
addMath('M3','Toán 5 • Số thập phân',[
['Giá trị hàng của số thập phân.','Trong 45,783 chữ số 8 ở hàng:',['Phần mười','Phần trăm','Phần nghìn','Chục'],1,'45,783: 7 phần mười, 8 phần trăm, 3 phần nghìn.'],
['So sánh số thập phân.','Số lớn nhất là:',['3,45','3,405','3,54','3,504'],2,'3,54 > 3,504 > 3,45 > 3,405.'],
['Cộng số thập phân.','12,6 + 4,35 bằng:',['16,95','16,85','17,05','15,95'],0,'12,60+4,35=16,95.'],
['Trừ số thập phân.','20 − 7,85 bằng:',['12,15','12,25','13,15','11,15'],0,'20,00−7,85=12,15.'],
['Nhân số thập phân với số tự nhiên.','3,6 × 5 bằng:',['18','1,8','180','8,6'],0,'36×5=180 rồi đặt một chữ số thập phân → 18,0.'],
['Nhân hai số thập phân.','1,2 × 0,5 bằng:',['0,6','6','0,06','1,7'],0,'12×5=60, có 2 chữ số thập phân → 0,60.'],
['Chia số thập phân cho số tự nhiên.','8,4 : 4 bằng:',['2,1','21','0,21','3,1'],0,'8,4 : 4 = 2,1.'],
['Nhân với 10,100,1000.','5,678 × 100 bằng:',['56,78','567,8','5 678','0,05678'],1,'Dịch dấu phẩy sang phải 2 chữ số.'],
['Chia cho 10,100,1000.','923,4 : 100 bằng:',['92,34','9,234','0,9234','92340'],1,'Dịch dấu phẩy sang trái 2 chữ số.'],
['Làm tròn số thập phân.','Làm tròn 6,47 đến hàng phần mười:',['6,4','6,5','6,47','7,0'],1,'Chữ số phần trăm là 7 nên tăng phần mười từ 4 lên 5.'],
['Đổi phân số thập phân.','37/100 viết thành số thập phân là:',['3,7','0,37','0,037','37,0'],1,'37 phần trăm = 0,37.'],
['Bài toán tiền.','Một quyển vở 12,5 nghìn đồng. 4 quyển giá:',['40 nghìn','45 nghìn','50 nghìn','52 nghìn'],2,'12,5×4=50 nghìn đồng.']
]);
addMath('M4','Toán 5 • Đại lượng & đo lường',[
['Đổi đơn vị độ dài.','3,5 km bằng:',['350 m','3 500 m','35 000 m','350 000 m'],1,'1 km=1000 m nên 3,5 km=3500 m.'],
['Đổi đơn vị khối lượng.','2,4 kg bằng:',['240 g','2 400 g','24 000 g','2400 kg'],1,'1 kg=1000 g.'],
['Đổi đơn vị diện tích.','1 m² bằng:',['10 cm²','100 cm²','1 000 cm²','10 000 cm²'],3,'1 m=100 cm nên 1 m²=100×100=10 000 cm².'],
['Đơn vị thời gian.','2 giờ 30 phút bằng:',['120 phút','130 phút','150 phút','230 phút'],2,'2 giờ=120 phút; +30=150 phút.'],
['Tính khoảng thời gian.','Từ 8:15 đến 10:00 là:',['1 giờ 15 phút','1 giờ 45 phút','2 giờ 15 phút','2 giờ 45 phút'],1,'8:15→9:15 là 1 giờ; →10:00 thêm 45 phút.'],
['Đổi lít và mililít.','1,75 lít bằng:',['175 ml','1 075 ml','1 750 ml','17 500 ml'],2,'1 lít=1000 ml.'],
['Vận tốc.','Đi 120 km trong 3 giờ, vận tốc là:',['30 km/h','40 km/h','60 km/h','360 km/h'],1,'v=s:t=120:3=40 km/h.'],
['Quãng đường.','Đi với 45 km/h trong 2 giờ, quãng đường là:',['22,5 km','47 km','90 km','135 km'],2,'s=v×t=45×2=90 km.'],
['Thời gian.','Đi 150 km với vận tốc 50 km/h mất:',['2 giờ','3 giờ','4 giờ','5 giờ'],1,'t=s:v=150:50=3 giờ.'],
['Tỉ lệ đơn giản.','4 hộp nặng 6 kg. Trung bình mỗi hộp nặng:',['1 kg','1,5 kg','2 kg','2,5 kg'],1,'6:4=1,5 kg.'],
['Đổi ha sang m².','2 ha bằng:',['2 000 m²','20 000 m²','200 000 m²','200 m²'],1,'1 ha=10 000 m².'],
['Bài toán đo lường.','Một chai chứa 1,5 lít. 6 chai chứa:',['7 lít','8 lít','9 lít','10 lít'],2,'1,5×6=9 lít.']
]);
addMath('M5','Toán 5 • Hình học',[
['Chu vi hình chữ nhật.','HCN dài 8 cm, rộng 5 cm. Chu vi là:',['13 cm','26 cm','40 cm','80 cm'],1,'P=(8+5)×2=26 cm.'],
['Diện tích hình chữ nhật.','HCN dài 9 cm, rộng 4 cm. Diện tích là:',['13 cm²','26 cm²','36 cm²','72 cm²'],2,'S=9×4=36 cm².'],
['Diện tích hình vuông.','Hình vuông cạnh 7 cm có diện tích:',['14 cm²','28 cm²','49 cm²','98 cm²'],2,'S=7×7=49 cm².'],
['Diện tích tam giác.','Tam giác đáy 10 cm, cao 6 cm. Diện tích:',['16 cm²','30 cm²','60 cm²','120 cm²'],1,'S=10×6:2=30 cm².'],
['Diện tích hình thang.','Hình thang có hai đáy 8 và 12 cm, cao 5 cm. S=',['40 cm²','50 cm²','60 cm²','100 cm²'],1,'S=(8+12)×5:2=50 cm².'],
['Chu vi đường tròn.','Đường tròn bán kính 5 cm, lấy π=3,14. Chu vi là:',['15,7 cm','31,4 cm','78,5 cm','157 cm'],1,'C=2×3,14×5=31,4 cm.'],
['Diện tích hình tròn.','Hình tròn bán kính 4 cm, lấy π=3,14. Diện tích:',['25,12 cm²','50,24 cm²','12,56 cm²','100,48 cm²'],1,'S=3,14×4×4=50,24 cm².'],
['Thể tích hình hộp chữ nhật.','Hộp dài 5, rộng 4, cao 3 cm. Thể tích:',['12 cm³','20 cm³','60 cm³','120 cm³'],2,'V=5×4×3=60 cm³.'],
['Thể tích hình lập phương.','Lập phương cạnh 4 cm có thể tích:',['16 cm³','32 cm³','64 cm³','128 cm³'],2,'V=4³=64 cm³.'],
['Nhận biết hình.','Hình có 4 cạnh bằng nhau và 4 góc vuông là:',['Hình thang','Hình vuông','Hình tam giác','Hình tròn'],1,'Đó là hình vuông.'],
['Tỉ số chu vi.','Hình vuông cạnh gấp đôi thì chu vi:',['Không đổi','Gấp 2','Gấp 4','Gấp 8'],1,'P=4a nên cạnh gấp đôi thì chu vi gấp đôi.'],
['Bài toán diện tích.','Sân HCN 20 m × 15 m. Diện tích:',['35 m²','70 m²','300 m²','600 m²'],2,'20×15=300 m².']
]);
addMath('M6','Toán 5 • Tỉ số phần trăm',[
['Hiểu phần trăm.','25% bằng phân số tối giản:',['1/2','1/4','1/5','3/4'],1,'25/100=1/4.'],
['Tìm phần trăm của một số.','20% của 150 là:',['20','25','30','35'],2,'150×20%=30.'],
['Tìm tỉ số phần trăm.','30 trên 120 chiếm:',['20%','25%','30%','40%'],1,'30:120=0,25=25%.'],
['Giảm giá.','Áo 400 000đ giảm 10%. Số tiền giảm:',['20 000đ','30 000đ','40 000đ','50 000đ'],2,'400 000×10%=40 000đ.'],
['Giá sau giảm.','Áo 400 000đ giảm 10%. Giá còn:',['340 000đ','350 000đ','360 000đ','390 000đ'],2,'400 000−40 000=360 000đ.'],
['Tăng phần trăm.','100 tăng 15% được:',['105','110','115','150'],2,'100+15=115.'],
['Điểm đúng.','Làm đúng 18/20 câu là:',['80%','85%','90%','95%'],2,'18:20=0,9=90%.'],
['Số học sinh.','40 học sinh, 60% nữ. Số nữ:',['20','22','24','26'],2,'40×60%=24.'],
['Phần trăm còn lại.','Một bể đầy 75%, phần chưa đầy là:',['15%','20%','25%','35%'],2,'100%−75%=25%.'],
['Tìm số khi biết phần trăm.','25% của một số bằng 50. Số đó là:',['100','150','200','250'],2,'50:25%=200.'],
['Tỉ lệ hoàn thành.','Hoàn thành 42/50 công việc bằng:',['80%','82%','84%','86%'],2,'42:50=0,84=84%.'],
['Bài toán thực tế.','Cửa hàng bán 70% của 200 sản phẩm. Đã bán:',['120','130','140','150'],2,'200×70%=140.']
]);
addMath('M7','Toán 5 • Biểu thức & bài toán',[
['Thứ tự phép tính.','18 + 6 × 5 bằng:',['120','48','60','30'],1,'Nhân trước: 6×5=30; 18+30=48.'],
['Dấu ngoặc.','(18 + 6) × 5 bằng:',['48','90','120','150'],2,'Trong ngoặc trước: 24×5=120.'],
['Tìm x.','x × 6 = 54. x=',['8','9','10','12'],1,'54:6=9.'],
['Tìm x.','x : 5 = 12. x=',['60','17','7','2,4'],0,'x=12×5=60.'],
['Trung bình cộng.','Trung bình của 12, 18, 24 là:',['16','18','20','54'],1,'(12+18+24):3=18.'],
['Bài toán hai bước.','Có 5 hộp, mỗi hộp 12 bút, cho đi 8 bút. Còn:',['52','60','68','40'],0,'5×12−8=52.'],
['Bài toán rút về đơn vị.','3 kg táo giá 90 000đ. 5 kg giá:',['120 000đ','140 000đ','150 000đ','180 000đ'],2,'1kg=30 000đ; 5kg=150 000đ.'],
['Tổng hiệu.','Tổng hai số 50, hiệu 10. Số lớn là:',['20','25','30','40'],2,'Số lớn=(50+10):2=30.'],
['Tổng hiệu.','Tổng 84, hiệu 16. Số bé là:',['34','40','50','68'],0,'Số bé=(84−16):2=34.'],
['Tỉ lệ thuận đơn giản.','2 quyển giá 30 000đ. 6 quyển giá:',['60 000đ','75 000đ','90 000đ','120 000đ'],2,'6 gấp 3 lần 2 nên giá gấp 3: 90 000đ.'],
['Tổng quãng đường.','Đi 35 km rồi thêm 28 km. Tổng:',['53 km','63 km','73 km','83 km'],1,'35+28=63 km.'],
['Bài toán năng suất.','Mỗi giờ làm 15 sản phẩm, 8 giờ làm:',['100','110','120','130'],2,'15×8=120.']
]);
addMath('M8','Toán 5 • Ôn tập tổng hợp',[
['Ôn số tự nhiên.','7 005 − 2 786 bằng:',['4 119','4 219','4 319','5 219'],1,'7005−2786=4219.'],
['Ôn phân số.','1/3 + 1/6 bằng:',['1/2','2/9','1/9','2/6'],0,'1/3=2/6; +1/6=3/6=1/2.'],
['Ôn thập phân.','6,25 × 4 bằng:',['25','24','2,5','250'],0,'6,25×4=25.'],
['Ôn phần trăm.','5% của 300 là:',['10','15','20','25'],1,'300×5%=15.'],
['Ôn hình học.','Tam giác đáy 8, cao 5 có S:',['20','40','13','80'],0,'8×5:2=20.'],
['Ôn đo lường.','2,5 giờ bằng:',['2 giờ 5 phút','2 giờ 30 phút','2 giờ 50 phút','150 giờ'],1,'0,5 giờ=30 phút.'],
['Ôn vận tốc.','180 km trong 4 giờ → v=',['40','45','50','60'],1,'180:4=45 km/h.'],
['Ôn biểu thức.','9×(7−3)=',['18','27','36','63'],2,'7−3=4; 9×4=36.'],
['Ôn trung bình.','TB của 10 và 18 là:',['12','13','14','15'],2,'(10+18):2=14.'],
['Ôn tỉ lệ.','3/4 của 80 là:',['40','50','60','70'],2,'80×3/4=60.'],
['Ôn làm tròn.','9,86 làm tròn hàng phần mười:',['9,8','9,9','10,0','9,86'],1,'Chữ số phần trăm 6 nên làm tròn lên.'],
['Ôn tiền.','3 món, mỗi món 45 000đ. Tổng:',['90 000đ','120 000đ','135 000đ','145 000đ'],2,'45 000×3=135 000đ.']
]);

const viet={
'V1':[
q('Tiếng Việt 5 • Từ loại','Danh từ gọi tên sự vật, hiện tượng, khái niệm.','Từ nào là danh từ?',['chạy','đẹp','học sinh','nhanh'],2,'“học sinh” là danh từ.'),
q('Tiếng Việt 5 • Từ loại','Động từ chỉ hoạt động hoặc trạng thái.','Từ nào là động từ?',['vui','đọc','quyển sách','xanh'],1,'“đọc” là động từ.'),
q('Tiếng Việt 5 • Từ loại','Tính từ chỉ đặc điểm, tính chất.','Từ nào là tính từ?',['cao','chạy','bạn bè','học'],0,'“cao” là tính từ.'),
q('Tiếng Việt 5 • Từ loại','Đại từ dùng để xưng hô hoặc thay thế.','Trong câu “Lan học giỏi. Bạn ấy rất chăm.”, “bạn ấy” là:',['Danh từ','Động từ','Đại từ','Quan hệ từ'],2,'“bạn ấy” thay cho Lan.'),
q('Tiếng Việt 5 • Từ loại','Quan hệ từ nối các từ/cụm từ.','Từ nào là quan hệ từ?',['và','đẹp','nhà','chạy'],0,'“và” dùng để nối.'),
q('Tiếng Việt 5 • Từ loại','Cặp quan hệ từ biểu thị nguyên nhân-kết quả.','Cặp nào đúng?',['nếu...thì','vì...nên','tuy...nhưng','không những...mà còn'],1,'“vì...nên” biểu thị nguyên nhân-kết quả.'),
q('Tiếng Việt 5 • Từ loại','Cặp quan hệ từ biểu thị điều kiện-kết quả.','Cặp nào đúng?',['nếu...thì','vì...nên','tuy...nhưng','bao nhiêu...bấy nhiêu'],0,'“nếu...thì” biểu thị điều kiện-kết quả.'),
q('Tiếng Việt 5 • Từ loại','Cặp quan hệ từ biểu thị tương phản.','Cặp nào đúng?',['vì...nên','tuy...nhưng','nếu...thì','do...nên'],1,'“tuy...nhưng” biểu thị tương phản.'),
q('Tiếng Việt 5 • Từ loại','Xác định tính từ trong câu.','Trong “Bầu trời hôm nay rất trong xanh”, tính từ là:',['bầu trời','hôm nay','rất','trong xanh'],3,'“trong xanh” chỉ đặc điểm.'),
q('Tiếng Việt 5 • Từ loại','Xác định động từ.','Trong “Em bé đang ngủ ngon”, động từ là:',['em bé','đang','ngủ','ngon'],2,'“ngủ” chỉ trạng thái/hoạt động.'),
q('Tiếng Việt 5 • Từ loại','Xác định danh từ.','Trong “Những bông hoa nở rực rỡ”, danh từ là:',['những','bông hoa','nở','rực rỡ'],1,'“bông hoa” là sự vật.'),
q('Tiếng Việt 5 • Từ loại','Phó từ bổ sung ý nghĩa cho động/tính từ.','Trong “Bạn Nam rất chăm chỉ”, “rất” có tác dụng:',['Gọi tên sự vật','Bổ sung mức độ','Chỉ hoạt động','Nối câu'],1,'“rất” bổ sung mức độ cho “chăm chỉ”.')
],
'V2':[
q('Tiếng Việt 5 • Từ đồng nghĩa','Từ đồng nghĩa có nghĩa giống hoặc gần giống nhau.','Cặp nào đồng nghĩa?',['chăm chỉ – siêng năng','cao – thấp','nhanh – chậm','vui – buồn'],0,'“chăm chỉ” và “siêng năng” gần nghĩa.'),
q('Tiếng Việt 5 • Từ trái nghĩa','Từ trái nghĩa có nghĩa đối lập.','Cặp nào trái nghĩa?',['to – lớn','hiền – lành','sáng – tối','nhanh – mau'],2,'“sáng” và “tối” đối lập.'),
q('Tiếng Việt 5 • Từ nhiều nghĩa','Một từ có thể có nghĩa gốc và nghĩa chuyển.','Trong “Mũi thuyền rẽ sóng”, “mũi” là:',['Nghĩa gốc','Nghĩa chuyển','Từ đồng âm','Danh từ riêng'],1,'“mũi” chuyển từ bộ phận cơ thể sang phần nhô ra phía trước.'),
q('Tiếng Việt 5 • Từ nhiều nghĩa','Nghĩa gốc là nghĩa ban đầu, trực tiếp.','Trong “Bé bị đau chân”, “chân” là:',['Nghĩa gốc','Nghĩa chuyển','Ẩn dụ','So sánh'],0,'“chân” là bộ phận cơ thể.'),
q('Tiếng Việt 5 • Từ đồng âm','Từ đồng âm giống âm nhưng khác nghĩa.','“đường” trong “đường ăn” và “đường đi” là:',['Đồng nghĩa','Trái nghĩa','Đồng âm','Nhiều nghĩa'],2,'Hai từ cùng âm nhưng nghĩa khác hẳn.'),
q('Tiếng Việt 5 • Nghĩa của từ','Chọn từ gần nghĩa với “dũng cảm”.',['can đảm','nhút nhát','lười biếng','ồn ào'],0,'“can đảm” gần nghĩa với “dũng cảm”.'),
q('Tiếng Việt 5 • Nghĩa của từ','Chọn từ trái nghĩa với “đoàn kết”.',['gắn bó','chia rẽ','hợp tác','thân thiết'],1,'“chia rẽ” đối lập với “đoàn kết”.'),
q('Tiếng Việt 5 • Nghĩa của từ','“Mắt lưới” trong “mắt lưới rất nhỏ” là:',['Nghĩa gốc','Nghĩa chuyển','Từ đồng âm','Động từ'],1,'“mắt” được dùng theo nghĩa chuyển.'),
q('Tiếng Việt 5 • Nghĩa của từ','Từ nào gần nghĩa với “bao la”?',['rộng lớn','chật hẹp','nhỏ bé','ngắn ngủi'],0,'“rộng lớn” gần nghĩa.'),
q('Tiếng Việt 5 • Nghĩa của từ','Từ nào trái nghĩa với “khiêm tốn”?',['nhã nhặn','tự phụ','hiền lành','chăm chỉ'],1,'“tự phụ” đối lập với “khiêm tốn”.'),
q('Tiếng Việt 5 • Nghĩa của từ','Trong “chân núi”, từ “chân” là:',['Nghĩa gốc','Nghĩa chuyển','Từ tượng thanh','Đại từ'],1,'“chân núi” là phần dưới cùng của núi.'),
q('Tiếng Việt 5 • Nghĩa của từ','“Cánh đồng” và “cánh tay” dùng “cánh” theo quan hệ:',['Hoàn toàn đồng âm','Nghĩa gốc và nghĩa chuyển','Trái nghĩa','Đồng nghĩa'],1,'“cánh” được mở rộng nghĩa theo hình dạng/chức năng.')
],
'V3':[
q('Tiếng Việt 5 • Câu','Câu đơn thường có một cụm chủ-vị nòng cốt.','Câu nào là câu đơn?',['Trời mưa.','Trời mưa nên đường trơn.','Vì trời mưa nên em ở nhà.','Mặc dù mệt nhưng bạn vẫn học.'],0,'“Trời mưa” có một cụm chủ-vị.'),
q('Tiếng Việt 5 • Chủ ngữ','Chủ ngữ nêu người/sự vật thực hiện hoặc mang đặc điểm.','Chủ ngữ trong “Những chú chim hót líu lo” là:',['những','chú chim','hót','líu lo'],1,'“Những chú chim” là chủ ngữ.'),
q('Tiếng Việt 5 • Vị ngữ','Vị ngữ nêu hoạt động, trạng thái, đặc điểm của chủ ngữ.','Vị ngữ trong “Mặt trời đỏ rực” là:',['Mặt trời','đỏ rực','đỏ','rực'],1,'“đỏ rực” nêu đặc điểm của mặt trời.'),
q('Tiếng Việt 5 • Trạng ngữ','Trạng ngữ bổ sung thời gian, nơi chốn, nguyên nhân...','Trong “Buổi sáng, em tập thể dục”, “Buổi sáng” là:',['Chủ ngữ','Vị ngữ','Trạng ngữ','Định ngữ'],2,'Đó là trạng ngữ chỉ thời gian.'),
q('Tiếng Việt 5 • Câu ghép','Câu ghép có từ hai cụm chủ-vị trở lên.','Câu nào là câu ghép?',['Em học bài.','Mẹ nấu cơm, bố đọc báo.','Trời xanh.','Hoa nở đẹp.'],1,'Có hai cụm chủ-vị: mẹ-nấu, bố-đọc.'),
q('Tiếng Việt 5 • Câu ghép','Các vế câu ghép có thể nối bằng quan hệ từ.','Chọn từ nối phù hợp: “... trời mưa ... chúng em vẫn đi học.”',['Vì...nên','Tuy...nhưng','Nếu...thì','Do...nên'],1,'Quan hệ tương phản dùng “tuy...nhưng”.'),
q('Tiếng Việt 5 • Câu khiến','Câu khiến dùng để yêu cầu, đề nghị.','Câu nào là câu khiến?',['Bạn tên gì?','Hãy mở sách trang 20.','Trời đẹp quá!','Em đang học.'],1,'“Hãy...” là dấu hiệu câu khiến.'),
q('Tiếng Việt 5 • Câu hỏi','Câu hỏi dùng để hỏi điều chưa biết.','Câu nào là câu hỏi?',['Bạn đã làm bài chưa?','Hãy ngồi xuống.','Ôi đẹp quá!','Em đi học.'],0,'Có từ hỏi “chưa?” và dấu hỏi.'),
q('Tiếng Việt 5 • Câu cảm','Câu cảm bộc lộ cảm xúc.','Câu nào là câu cảm?',['Bạn đi đâu?','Hãy cố lên!','Ôi, cảnh đẹp quá!','Em đọc sách.'],2,'Có từ cảm thán “Ôi” và bộc lộ cảm xúc.'),
q('Tiếng Việt 5 • Liên kết câu','Lặp từ ngữ có thể liên kết câu.','“Lan có một chú mèo. Chú mèo rất ngoan.” liên kết bằng:',['Lặp từ ngữ','Thay thế từ ngữ','Nối','Đối lập'],0,'“chú mèo” được lặp lại.'),
q('Tiếng Việt 5 • Liên kết câu','Dùng đại từ để thay thế tránh lặp.','“Mai học giỏi. Bạn ấy còn hát hay.” dùng phép:',['Lặp','Thay thế','Nối','So sánh'],1,'“Bạn ấy” thay cho “Mai”.'),
q('Tiếng Việt 5 • Dấu câu','Dấu hai chấm có thể báo hiệu lời nói trực tiếp.','Câu nào dùng dấu hai chấm đúng?',['Mẹ nói: “Con nhớ học bài.”','Mẹ: nói con nhớ học bài.','Mẹ nói con: nhớ học bài.','Mẹ nói con nhớ: học bài.'],0,'Dấu hai chấm đứng trước lời dẫn trực tiếp.')
],
'V4':[
q('Tiếng Việt 5 • Biện pháp tu từ','So sánh đối chiếu sự vật này với sự vật khác.','Câu nào có so sánh?',['Mặt hồ như tấm gương.','Mặt hồ yên ả.','Mặt hồ rộng.','Mặt hồ xanh.'],0,'Có từ “như” so sánh mặt hồ với tấm gương.'),
q('Tiếng Việt 5 • Nhân hóa','Nhân hóa gọi/tả vật như người.','Câu nào có nhân hóa?',['Gió chạy nhảy trên cánh đồng.','Gió rất mạnh.','Gió thổi từ đông.','Hôm nay có gió.'],0,'“chạy nhảy” là hoạt động của người gán cho gió.'),
q('Tiếng Việt 5 • Điệp từ','Điệp từ lặp lại từ ngữ để nhấn mạnh.','Câu “Rất xanh, rất xanh, hàng cây trước ngõ” dùng:',['So sánh','Nhân hóa','Điệp từ','Ẩn dụ'],2,'Từ “rất xanh” được lặp lại.'),
q('Tiếng Việt 5 • Hình ảnh','Từ ngữ gợi tả giúp câu văn sinh động.','Từ nào gợi tả màu sắc rõ nhất?',['đi','xanh biếc','nói','ngồi'],1,'“xanh biếc” gợi tả màu sắc.'),
q('Tiếng Việt 5 • Tượng thanh','Từ tượng thanh mô phỏng âm thanh.','Từ nào là từ tượng thanh?',['lấp lánh','róc rách','mênh mông','đỏ thắm'],1,'“róc rách” mô phỏng tiếng nước.'),
q('Tiếng Việt 5 • Tượng hình','Từ tượng hình gợi hình ảnh, dáng vẻ.','Từ nào là từ tượng hình?',['lom khom','ào ào','ríu rít','ầm ầm'],0,'“lom khom” gợi dáng người.'),
q('Tiếng Việt 5 • So sánh','So sánh thường có từ như, tựa, giống...','“Trăng tròn như chiếc đĩa bạc” so sánh trăng với:',['bầu trời','chiếc đĩa bạc','ánh sáng','mây'],1,'Hình ảnh so sánh là “chiếc đĩa bạc”.'),
q('Tiếng Việt 5 • Nhân hóa','Nhân hóa làm sự vật gần gũi.','“Ông mặt trời thức dậy” nhân hóa ở từ:',['ông','mặt trời','thức dậy','Cả “ông” và “thức dậy”'],3,'Cả cách gọi “ông” và hoạt động “thức dậy” đều nhân hóa.'),
q('Tiếng Việt 5 • Tu từ','Câu nào không dùng biện pháp tu từ?',['Mặt trời đỏ như quả cầu lửa.','Cây bàng dang tay đón gió.','Con đường dài 2 km.','Sóng hát rì rào.'],2,'Đây là câu miêu tả thông tin trực tiếp.'),
q('Tiếng Việt 5 • Miêu tả','Chi tiết nào giàu hình ảnh nhất?',['hoa','hoa đỏ','những chùm hoa đỏ rực rung rinh trong nắng','có hoa'],2,'Cụm từ có màu sắc và chuyển động cụ thể.'),
q('Tiếng Việt 5 • Từ gợi cảm','Từ nào gợi cảm xúc tích cực?',['ấm áp','lạnh lẽo','u ám','cô quạnh'],0,'“ấm áp” thường gợi cảm xúc tích cực.'),
q('Tiếng Việt 5 • Biểu đạt','Câu văn nào giàu hình ảnh hơn?',['Trời có mây.','Mây trắng bồng bềnh trôi như những chiếc thuyền nhỏ.','Có nhiều mây.','Mây ở trên trời.'],1,'Có hình ảnh so sánh và từ gợi tả.')
],
'V5':[
q('Tiếng Việt 5 • Đọc hiểu','Đọc hiểu cần xác định ý chính.','Ý chính của một đoạn văn là:',['Chi tiết nhỏ nhất','Nội dung quan trọng bao quát đoạn','Tên tác giả','Số câu trong đoạn'],1,'Ý chính bao quát nội dung trọng tâm.'),
q('Tiếng Việt 5 • Đọc hiểu','Chi tiết hỗ trợ làm rõ ý chính.','Khi trả lời câu hỏi đọc hiểu, nên:',['Đoán tùy ý','Dựa vào bằng chứng trong bài','Chỉ nhìn tiêu đề','Bỏ qua từ khóa'],1,'Cần dựa vào văn bản.'),
q('Tiếng Việt 5 • Suy luận','Suy luận là rút ra điều hợp lí từ dữ kiện.','Nếu nhân vật mang ô và trời nhiều mây đen, có thể suy luận:',['Trời sắp mưa','Trời sắp nắng','Nhân vật đi ngủ','Nhân vật đi bơi'],0,'Dữ kiện gợi khả năng trời mưa.'),
q('Tiếng Việt 5 • Từ khóa','Từ khóa giúp nhận ra nội dung chính.','Từ khóa thường là:',['Từ ít liên quan','Từ/cụm từ quan trọng lặp hoặc nổi bật','Dấu chấm','Chữ cái đầu'],1,'Từ khóa tập trung nội dung chính.'),
q('Tiếng Việt 5 • Nhân vật','Đặc điểm nhân vật thể hiện qua:',['Lời nói, hành động, suy nghĩ','Chỉ tên nhân vật','Chỉ tuổi','Chỉ nơi ở'],0,'Các chi tiết này thể hiện tính cách rõ nhất.'),
q('Tiếng Việt 5 • Trình tự','Trình tự thời gian thường có dấu hiệu:',['trước tiên, sau đó, cuối cùng','vì, nên','nhưng, tuy','như, giống'],0,'Các từ này đánh dấu trình tự.'),
q('Tiếng Việt 5 • Nguyên nhân-kết quả','Từ nối nào báo nguyên nhân-kết quả?',['vì...nên','tuy...nhưng','nếu...thì','và'],0,'“vì...nên” biểu thị nguyên nhân-kết quả.'),
q('Tiếng Việt 5 • Tiêu đề','Tiêu đề phù hợp cần:',['Dài nhất có thể','Phản ánh nội dung chính','Không liên quan','Chỉ có một chữ'],1,'Tiêu đề nên cô đọng nội dung chính.'),
q('Tiếng Việt 5 • Thông tin tường minh','Thông tin tường minh là:',['Được nói trực tiếp trong văn bản','Phải đoán hoàn toàn','Không có trong bài','Chỉ có ở hình'],0,'Tường minh = được nêu rõ.'),
q('Tiếng Việt 5 • Thông tin hàm ẩn','Thông tin hàm ẩn cần:',['Suy luận từ chi tiết','Chép nguyên câu','Bỏ qua ngữ cảnh','Chỉ xem dấu câu'],0,'Hàm ẩn cần suy luận hợp lí.'),
q('Tiếng Việt 5 • Cảm nhận','Cảm nhận về văn bản nên:',['Có lí lẽ và dẫn chứng','Chỉ nói “hay”','Không cần căn cứ','Chép lại toàn bài'],0,'Cần có nhận xét kèm căn cứ.'),
q('Tiếng Việt 5 • Tóm tắt','Tóm tắt tốt cần:',['Giữ ý chính, lược chi tiết phụ','Chép nguyên văn','Thêm nhiều chi tiết mới','Đổi hoàn toàn nội dung'],0,'Tóm tắt giữ cốt lõi nội dung.')
],
'V6':[
q('Tiếng Việt 5 • Viết đoạn','Đoạn văn thường có câu mở, phát triển và kết.','Câu mở đoạn có nhiệm vụ chính:',['Giới thiệu nội dung đoạn','Kết luận toàn bài','Liệt kê dấu câu','Ghi tên người viết'],0,'Câu mở đoạn dẫn vào nội dung.'),
q('Tiếng Việt 5 • Miêu tả','Bài văn tả người nên chú ý:',['Ngoại hình, hoạt động, tính cách','Chỉ tuổi','Chỉ tên','Chỉ chiều cao'],0,'Cần nhiều phương diện để chân thực.'),
q('Tiếng Việt 5 • Tả cảnh','Tả cảnh nên quan sát theo:',['Trình tự hợp lí','Hoàn toàn ngẫu nhiên','Chỉ một chi tiết','Không dùng giác quan'],0,'Trình tự giúp bài rõ ràng.'),
q('Tiếng Việt 5 • Kể chuyện','Kể chuyện cần có:',['Nhân vật, sự việc, diễn biến','Chỉ tiêu đề','Chỉ lời thoại','Chỉ miêu tả'],0,'Đó là các yếu tố cốt lõi.'),
q('Tiếng Việt 5 • Mở bài','Mở bài trực tiếp là:',['Giới thiệu ngay đối tượng/sự việc','Kể vòng qua chuyện khác','Chỉ nêu cảm xúc cuối bài','Không liên quan'],0,'Mở trực tiếp đi ngay vào đối tượng.'),
q('Tiếng Việt 5 • Kết bài','Kết bài mở rộng có thể:',['Nêu thêm suy nghĩ, liên hệ','Chỉ nhắc lại tiêu đề','Không có cảm xúc','Bỏ trống'],0,'Kết mở rộng thêm liên hệ/cảm nghĩ.'),
q('Tiếng Việt 5 • Liên kết đoạn','Từ nối nào thể hiện bổ sung?',['hơn nữa','tuy nhiên','vì vậy','nếu'],0,'“hơn nữa” bổ sung ý.'),
q('Tiếng Việt 5 • Liên kết đoạn','Từ nối nào thể hiện kết quả?',['vì vậy','mặc dù','và','nếu'],0,'“vì vậy” báo kết quả.'),
q('Tiếng Việt 5 • Chỉnh sửa','Sau khi viết nên:',['Đọc lại và sửa lỗi','Nộp ngay không xem','Xóa hết','Chỉ sửa chữ đẹp'],0,'Đọc lại giúp sửa nội dung và diễn đạt.'),
q('Tiếng Việt 5 • Diễn đạt','Câu văn rõ ràng nên:',['Đủ ý, đúng ngữ pháp','Càng dài càng tốt','Lặp từ nhiều','Dùng từ không chính xác'],0,'Rõ nghĩa và đúng cấu trúc là quan trọng.'),
q('Tiếng Việt 5 • Lập dàn ý','Dàn ý giúp:',['Sắp xếp ý mạch lạc','Làm bài dài hơn','Không cần suy nghĩ','Thay cho bài viết'],0,'Dàn ý tổ chức nội dung trước khi viết.'),
q('Tiếng Việt 5 • Miêu tả','Dùng giác quan giúp:',['Chi tiết sinh động hơn','Bài ngắn hơn','Không cần từ ngữ','Không cần quan sát'],0,'Quan sát đa giác quan làm bài cụ thể.')
],
'V7':[
q('Tiếng Việt 5 • Chính tả','Âm đầu dễ lẫn cần dựa vào nghĩa và quy tắc.','Từ nào viết đúng?',['xinh sắn','xinh xắn','sinh xắn','xinh săn'],1,'Viết đúng là “xinh xắn”.'),
q('Tiếng Việt 5 • Chính tả','Chọn từ đúng chính tả.',['sạch sẽ','sạch sẻ','xạch sẽ','sạch xẽ'],0,'“sạch sẽ” đúng chính tả.'),
q('Tiếng Việt 5 • Chính tả','Chọn cách viết đúng.',['trân trọng','chân trọng','trân chọng','chân chọng'],0,'“trân trọng” đúng.'),
q('Tiếng Việt 5 • Chính tả','Chọn cách viết đúng.',['giành chiến thắng','dành chiến thắng','giành chiến thắn','dành chiến thắn'],0,'“giành” dùng cho tranh lấy/đạt được.'),
q('Tiếng Việt 5 • Chính tả','“dành” dùng đúng trong câu nào?',['Dành thời gian đọc sách.','Dành chiến thắng.','Dành giải nhất.','Dành lấy cờ.'],0,'“dành” = để riêng/để cho.'),
q('Tiếng Việt 5 • Viết hoa','Tên riêng Việt Nam cần:',['Viết hoa chữ cái đầu mỗi tiếng','Viết thường hết','Chỉ viết hoa họ','Chỉ viết hoa tên'],0,'Ví dụ: Nguyễn Văn An.'),
q('Tiếng Việt 5 • Dấu câu','Cuối câu hỏi dùng:',['.','?','!',':'],1,'Câu hỏi kết thúc bằng dấu hỏi.'),
q('Tiếng Việt 5 • Dấu câu','Dấu ngoặc kép thường dùng để:',['Đánh dấu lời nói trực tiếp hoặc từ đặc biệt','Kết thúc câu hỏi','Ngăn cách chủ-vị','Thay dấu phẩy'],0,'Đó là công dụng phổ biến.'),
q('Tiếng Việt 5 • Chính tả','Từ nào viết đúng?',['nghỉ ngơi','ngĩ ngơi','nghĩ ngơi','nghỉ nghơi'],0,'“nghỉ ngơi” đúng.'),
q('Tiếng Việt 5 • Chính tả','Từ nào viết đúng?',['kiên trì','kiêng trì','kiên chì','kiêng chì'],0,'“kiên trì” đúng.'),
q('Tiếng Việt 5 • Viết hoa','Tên cơ quan, tổ chức thường:',['Viết hoa theo quy tắc tên riêng','Không viết hoa','Viết hoa mọi chữ cái','Chỉ viết hoa chữ cuối'],0,'Cần tuân quy tắc viết hoa tên riêng tổ chức.'),
q('Tiếng Việt 5 • Dấu phẩy','Dấu phẩy có thể dùng để:',['Ngăn cách các bộ phận cùng chức vụ','Kết thúc mọi câu','Thay dấu hỏi','Chỉ tên riêng'],0,'Dấu phẩy ngăn cách thành phần liệt kê, trạng ngữ...')
],
'V8':[
q('Tiếng Việt 5 • Ôn tập','Chọn từ loại đúng của “nhanh” trong “Bạn chạy rất nhanh”.',['Danh từ','Động từ','Tính từ/ từ chỉ đặc điểm cách thức','Quan hệ từ'],2,'“nhanh” bổ sung đặc điểm cho hoạt động chạy.'),
q('Tiếng Việt 5 • Ôn tập','Câu “Vì mưa to nên đường ngập” biểu thị:',['Điều kiện','Nguyên nhân-kết quả','Tương phản','Tăng tiến'],1,'Dùng cặp “vì...nên”.'),
q('Tiếng Việt 5 • Ôn tập','Cặp từ nào đồng nghĩa?',['bao la – rộng lớn','cao – thấp','vui – buồn','sáng – tối'],0,'Hai từ gần nghĩa.'),
q('Tiếng Việt 5 • Ôn tập','“Cây bàng vẫy tay chào gió” dùng:',['So sánh','Nhân hóa','Điệp từ','Hoán dụ'],1,'Gán hành động người cho cây.'),
q('Tiếng Việt 5 • Ôn tập','Chủ ngữ trong “Buổi chiều, đàn chim bay về tổ” là:',['Buổi chiều','đàn chim','bay','về tổ'],1,'“Buổi chiều” là trạng ngữ, “đàn chim” là chủ ngữ.'),
q('Tiếng Việt 5 • Ôn tập','Câu nào là câu ghép?',['Nắng lên.','Nắng lên và chim bắt đầu hót.','Trời xanh.','Em vui.'],1,'Có hai cụm chủ-vị: nắng-lên, chim-hót.'),
q('Tiếng Việt 5 • Ôn tập','Từ trái nghĩa với “lạc quan” là:',['vui vẻ','bi quan','tự tin','kiên trì'],1,'“bi quan” đối lập với “lạc quan”.'),
q('Tiếng Việt 5 • Ôn tập','Mục đích của tóm tắt là:',['Nêu ngắn gọn ý chính','Chép nguyên bài','Thêm sự kiện','Đổi nhân vật'],0,'Tóm tắt giữ những ý cốt lõi.'),
q('Tiếng Việt 5 • Ôn tập','Khi viết bài, dàn ý giúp:',['Sắp xếp ý','Làm chữ đẹp','Tăng số trang','Bỏ mở bài'],0,'Dàn ý tổ chức logic.'),
q('Tiếng Việt 5 • Ôn tập','Câu nào dùng dấu hai chấm đúng?',['Cô dặn: “Các em nhớ học bài.”','Cô: dặn các em.','Cô dặn các: em.','Cô dặn các em: nhớ.'],0,'Dấu hai chấm báo hiệu lời dẫn.'),
q('Tiếng Việt 5 • Ôn tập','Từ nào viết đúng chính tả?',['sắp xếp','xắp xếp','sắp xép','xắp xép'],0,'“sắp xếp” đúng.'),
q('Tiếng Việt 5 • Ôn tập','Một đoạn văn mạch lạc cần:',['Các câu liên kết và cùng chủ đề','Các câu rời rạc','Nhiều từ khó','Không cần câu mở'],0,'Liên kết và thống nhất chủ đề tạo mạch lạc.')
]
};

const eng={};
const units=[
['E1','Unit 1 • All about me','Introducing yourself and personal information',[
['What is your name?',['My name is Minh.','I am ten years old.','I live in Hanoi.','I like football.'],0],
['How old are you?',['I am eleven.','I am fine.','I am from Vietnam.','At seven.'],0],
['Where are you from?',['I am from Vietnam.','I am eleven.','I like music.','By bus.'],0],
['Choose the correct sentence.',['I am from Hanoi.','I from Hanoi.','I am come Hanoi.','I is from Hanoi.'],0],
['Complete: “Nice to ___ you.”',['meet','meets','meeting','met'],0],
['Which question asks about hometown?',['Where do you live?','How often do you study?','What time is it?','What are you doing?'],0]
]],
['E2','Unit 2 • Daily routines','Talking about daily routines and time',[
['What time do you get up?',['At six thirty.','In my bedroom.','Every day.','With my sister.'],0],
['I ___ my teeth every morning.',['brush','brushes','brushing','brushed'],0],
['She ___ breakfast at seven.',['has','have','having','had'],0],
['What do you do after school?',['I do my homework.','At four o’clock.','By bicycle.','In the classroom.'],0],
['Choose the correct frequency phrase.',['every day','at school','blue shirt','two books'],0],
['“Usually” means:',['most of the time','never','one time only','yesterday'],0]
]],
['E3','Unit 3 • School subjects','Talking about school subjects and schedules',[
['What is your favourite subject?',['English.','At school.','On Monday.','With Lan.'],0],
['How often do you have English?',['Four times a week.','In Room 5.','It is easy.','My teacher.'],0],
['We have Maths ___ Monday.',['on','in','at','for'],0],
['Which subject studies numbers?',['Maths','Music','Art','PE'],0],
['“Twice a week” tells us about:',['frequency','place','colour','reason'],0],
['Do you have Science today?',['Yes, I do.','Yes, I am.','Yes, it is.','Yes, I have do.'],0]
]],
['E4','Unit 4 • Free time','Talking about hobbies and leisure',[
['What do you do in your free time?',['I read comics.','At five.','In the library.','Because it is sunny.'],0],
['I like ___ badminton.',['playing','play','plays','played'],0],
['My hobby is ___.',['drawing','draw','draws','drew'],0],
['How often do you watch TV?',['Sometimes.','At home.','A cartoon.','With my brother.'],0],
['Which is a hobby?',['collecting stamps','doing homework','taking a test','waiting in line'],0],
['She enjoys ___ books.',['reading','read','reads','to reading'],0]
]],
['E5','Unit 5 • Friends','Describing friends and personality',[
['What is your best friend like?',['She is kind and helpful.','She likes noodles.','She is at school.','She is eleven years.'],0],
['“Friendly” means:',['kind to other people','very angry','very tired','very quiet always'],0],
['He has ___ hair.',['short black','black short','shortly black','a short black'],0],
['My friend always helps me. He is ___.',['helpful','lazy','rude','careless'],0],
['Which adjective describes personality?',['honest','kitchen','swim','Monday'],0],
['Choose the correct sentence.',['She is taller than me.','She taller than me.','She is tall than me.','She more tall me.'],0]
]],
['E6','Unit 6 • Family','Talking about family members',[
['Who is your mother’s mother?',['grandmother','aunt','sister','cousin'],0],
['My father’s brother is my ___.',['uncle','cousin','nephew','grandfather'],0],
['How many people are there in your family?',['There are four.','They are fine.','At home.','Four years.'],0],
['My sister is ___ than me.',['younger','young','more young','youngest than'],0],
['Which word is a family member?',['cousin','kitchen','teacher','market'],0],
['We ___ dinner together every evening.',['have','has','having','had usually'],0]
]],
['E7','Unit 7 • Food and drink','Talking about food preferences',[
['What would you like to eat?',['I’d like some noodles.','At noon.','In the kitchen.','It is delicious.'],0],
['Would you like some juice?',['Yes, please.','Yes, I like.','I am juice.','No, I do.'],0],
['Which is countable?',['apple','rice','water','milk'],0],
['There ___ some rice on the table.',['is','are','be','am'],0],
['There ___ two bananas.',['are','is','am','be'],0],
['“Delicious” means:',['very tasty','very expensive','very cold','very small'],0]
]],
['E8','Unit 8 • Health','Talking about health problems and advice',[
['What’s the matter with you?',['I have a headache.','I am at home.','I like apples.','At eight.'],0],
['You have a fever. You should ___.',['rest','run outside','eat ice cream','stay up late'],0],
['You ___ eat too much candy.',['shouldn’t','should','can to','are'],0],
['Which is a health problem?',['toothache','homework','museum','weather'],0],
['I have a sore throat. I should drink ___.',['warm water','very cold soda','paint','sand'],0],
['“Should” is used for:',['advice','past time','location','colour'],0]
]],
['E9','Unit 9 • Weather','Talking about weather and seasons',[
['What’s the weather like today?',['It’s sunny.','It’s Monday.','At school.','I’m fine.'],0],
['It is very cold in ___.',['winter','summer','spring hot','August only'],0],
['Which word describes weather?',['cloudy','teacher','kitchen','football'],0],
['Take an umbrella. It is ___.',['raining','reading','running','drawing'],0],
['What do you wear when it is cold?',['a coat','shorts only','sandals','a swimsuit'],0],
['The weather is ___ than yesterday.',['warmer','warm','more warmest','warmest than'],0]
]],
['E10','Unit 10 • Places in town','Asking for and giving directions',[
['Where is the post office?',['It is next to the bank.','It is five o’clock.','I like it.','By bus.'],0],
['Go straight and turn ___.',['left','sunny','slowly book','Monday'],0],
['The library is ___ the school and the park.',['between','under at','for','during'],0],
['Which place can you borrow books from?',['library','bakery','hospital','stadium'],0],
['Excuse me, how can I get to the museum?',['Go straight for two blocks.','It is beautiful.','At nine.','I go yesterday.'],0],
['“Opposite” means:',['across from','inside','behind only','far away always'],0]
]],
['E11','Unit 11 • Transport','Talking about ways of travelling',[
['How do you go to school?',['By bike.','At seven.','Every day.','With books.'],0],
['Which is public transport?',['bus','bicycle helmet','shoe','desk'],0],
['I go to school ___ bus.',['by','on a','with','at'],0],
['She walks ___ school.',['to','at','by','from at'],0],
['Which is the fastest?',['plane','bicycle','walking','scooter usually'],0],
['We waited for the train at the ___.',['station','library','kitchen','classroom'],0]
]],
['E12','Unit 12 • Holidays','Talking about past holidays',[
['Where did you go last summer?',['I went to Da Nang.','I go to Da Nang.','At summer.','Tomorrow.'],0],
['What did you do there?',['I swam in the sea.','I swim now.','I will swim yesterday.','At the beach.'],0],
['The past of “go” is:',['went','goed','gone yesterday','going'],0],
['The past of “see” is:',['saw','seed','seen yesterday','seeing'],0],
['Did you enjoy the trip?',['Yes, I did.','Yes, I do.','Yes, I am.','Yes, I was enjoy.'],0],
['We ___ many photos yesterday.',['took','take','taken now','taking'],0]
]],
['E13','Unit 13 • Future plans','Talking about future intentions',[
['What are you going to do this weekend?',['I’m going to visit my grandparents.','I visited them yesterday.','At home.','Every day.'],0],
['She is going to ___ a cake.',['make','makes','made','making to'],0],
['We ___ visit Hue next month.',['will','did','are yesterday','were'],0],
['Which phrase refers to the future?',['next week','last week','yesterday','two days ago'],0],
['I think it ___ rain tomorrow.',['will','did','was','has yesterday'],0],
['Are you going to play football?',['Yes, I am.','Yes, I do yesterday.','Yes, I was.','Yes, I going.'],0]
]],
['E14','Unit 14 • Animals','Describing animals and habitats',[
['Which animal lives in the ocean?',['dolphin','tiger','elephant','monkey'],0],
['A giraffe is very ___.',['tall','shortest tiny','underwater','round food'],0],
['Birds can usually ___.',['fly','drive','read','cook'],0],
['Which animal has a trunk?',['elephant','lion','rabbit','penguin'],0],
['A panda mainly eats ___.',['bamboo','fish only','grass seeds only','meat'],0],
['“Wild animal” means an animal that:',['lives in nature','always lives in a house','is a toy','is made of wood'],0]
]],
['E15','Unit 15 • Nature','Talking about the environment',[
['We should ___ trees.',['plant','cut all','waste','burn'],0],
['We should not ___ water.',['waste','save','reuse','protect'],0],
['Which item can often be recycled?',['paper','dirty smoke','sunlight','rain'],0],
['To protect the environment, we can:',['use reusable bags','throw rubbish everywhere','leave lights on','waste food'],0],
['“Pollution” means:',['harmful dirt in the environment','a school lesson','a healthy meal','a holiday'],0],
['Turn off the lights to save ___.',['energy','noise','homework','traffic'],0]
]],
['E16','Unit 16 • Jobs','Talking about occupations',[
['Who works in a hospital?',['doctor','pilot','farmer only','chef at school always'],0],
['A teacher works at a ___.',['school','airport','farm','station'],0],
['Who flies an airplane?',['pilot','dentist','nurse','baker'],0],
['What do you want to be?',['I want to be an engineer.','At work.','Every day.','I am ten.'],0],
['A chef usually works in a ___.',['restaurant','library','garage only','classroom'],0],
['Which job helps sick people?',['doctor','artist','driver','musician'],0]
]],
['E17','Unit 17 • Technology','Talking about devices and safe use',[
['What do you use a computer for?',['I use it to study.','At home.','It is blue.','Every night.'],0],
['Which device can take photos?',['smartphone','pencil','notebook','ruler'],0],
['We should keep our password ___.',['private','on the wall','very public','shared with everyone'],0],
['Too much screen time can make your eyes ___.',['tired','taller','faster','delicious'],0],
['Clicking unknown links can be ___.',['unsafe','healthy','delicious','quiet'],0],
['“Online” means:',['connected to the internet','inside a book','under water','without electricity always'],0]
]],
['E18','Unit 18 • Festivals','Talking about celebrations and culture',[
['Tet is a Vietnamese ___.',['festival','subject','vehicle','job'],0],
['At Tet, people often visit their ___.',['relatives','airports','hospitals','factories'],0],
['What do people do at a birthday party?',['give presents','take an exam','go to work only','sleep in class'],0],
['Which word means “lễ hội”?',['festival','station','medicine','weather'],0],
['We decorated the room ___ balloons.',['with','at','by a','for to'],0],
['People often say “Happy New Year” ___ Tet.',['at','in to','by','from'],0]
]],
['E19','Unit 19 • Stories','Reading and talking about simple stories',[
['A story usually has:',['characters and events','only numbers','only a map','only questions'],0],
['“Once upon a time” often begins a:',['story','math problem','recipe','weather report'],0],
['Who is the main character?',['the most important person/animal in the story','the reader only','the book cover','the page number'],0],
['“Finally” often signals:',['the ending','the beginning','a place','a colour'],0],
['Past stories often use verbs like:',['went and saw','go and see now','will go only','going tomorrow'],0],
['A moral is:',['a lesson from a story','a character’s age','the book price','the page title only'],0]
]],
['E20','Unit 20 • Review & communication','Reviewing key communication functions',[
['Choose a polite request.',['Could you help me, please?','Help me now!','You help.','Helping me.'],0],
['Choose a good response to “Thank you.”',['You’re welcome.','I’m sorry.','Never mind?','Good night only.'],0],
['Choose the correct apology.',['I’m sorry I’m late.','Thank you I’m late.','Please I’m late.','Welcome I’m late.'],0],
['Which question asks about frequency?',['How often do you exercise?','Where do you live?','What colour is it?','Who is she?'],0],
['Which question asks about a past event?',['What did you do yesterday?','What are you doing now?','What will you do tomorrow?','What do you usually do?'],0],
['Which sentence gives advice?',['You should drink more water.','I drank water yesterday.','Water is blue.','I have two bottles.'],0]
]]
];
units.forEach(([key,title,summary,arr])=>{eng[key]=arr.map((x,i)=>q(title,summary,x[0],x[1],x[2],`Đáp án đúng: ${x[1][x[2]]}.`, i%3===0?'Hội thoại':i%3===1?'Ngữ pháp':'Từ vựng'));});

window.GRADE5_BANK={grade5_math:math,grade5_viet:viet,grade5_eng:eng};
window.GRADE5_META={
 grade5_math:{M1:'Số tự nhiên',M2:'Phân số',M3:'Số thập phân',M4:'Đo lường',M5:'Hình học',M6:'Phần trăm',M7:'Bài toán',M8:'Ôn tập'},
 grade5_viet:{V1:'Từ loại',V2:'Nghĩa của từ',V3:'Câu & liên kết',V4:'Tu từ',V5:'Đọc hiểu',V6:'Tập làm văn',V7:'Chính tả',V8:'Ôn tập'},
 grade5_eng:{E1:'Unit 1',E2:'Unit 2',E3:'Unit 3',E4:'Unit 4',E5:'Unit 5',E6:'Unit 6',E7:'Unit 7',E8:'Unit 8',E9:'Unit 9',E10:'Unit 10',E11:'Unit 11',E12:'Unit 12',E13:'Unit 13',E14:'Unit 14',E15:'Unit 15',E16:'Unit 16',E17:'Unit 17',E18:'Unit 18',E19:'Unit 19',E20:'Unit 20'}
};
})();
