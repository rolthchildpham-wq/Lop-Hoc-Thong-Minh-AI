(function(){
  const LANGS={
    vi:{locale:'vi-VN',label:'Việt',storage:'ai_voice_vi',prefer:[/natural/i,/neural/i,/premium/i,/hoai\s*my/i,/nam\s*minh/i,/vietnamese/i,/google.*vi/i,/microsoft.*vi/i,/apple.*vi/i]},
    en:{locale:'en-US',label:'English',storage:'ai_voice_en',prefer:[/natural/i,/neural/i,/premium/i,/aria/i,/jenny/i,/guy/i,/samantha/i,/ava/i,/andrew/i,/google.*us.*english/i,/microsoft.*english/i]},
    zh:{locale:'zh-CN',label:'中文',storage:'ai_voice_zh',prefer:[/natural/i,/neural/i,/premium/i,/xiaoxiao/i,/yunxi/i,/xiaoyi/i,/tingting/i,/mei[- ]?jia/i,/google.*中文/i,/microsoft.*chinese/i]}
  };
  const robotPatterns=[/espeak/i,/festival/i,/compact/i,/mbrola/i];
  const state={ready:false,voices:[],selected:{vi:null,en:null,zh:null},status:'loading'};
  let sequenceId=0;

  function langKey(locale){
    const x=(locale||'').toLowerCase();
    if(x.startsWith('zh'))return 'zh';
    if(x.startsWith('en'))return 'en';
    return 'vi';
  }
  function scoreVoice(v,key){
    const cfg=LANGS[key], name=v.name||'', lang=(v.lang||'').toLowerCase();
    const target=cfg.locale.toLowerCase(), base=target.split('-')[0];
    if(!lang.startsWith(base)) return -9999;
    let s=lang===target?120:90;
    cfg.prefer.forEach((r,i)=>{if(r.test(name)) s+=45-i;});
    robotPatterns.forEach(r=>{if(r.test(name))s-=120;});
    if(/natural|neural|premium|enhanced/i.test(name))s+=45;
    if(v.localService===false)s+=10;
    if(key==='en' && /en[-_ ]?(us|gb)|american|british/i.test((lang+' '+name)))s+=10;
    if(key==='zh' && /mandarin|putonghua|普通话|中文/i.test(name+' '+lang))s+=12;
    return s;
  }
  function pick(key,list){
    const cfg=LANGS[key], saved=localStorage.getItem(cfg.storage);
    const candidates=list.filter(v=>(v.lang||'').toLowerCase().startsWith(cfg.locale.slice(0,2).toLowerCase()));
    let chosen=saved?candidates.find(v=>v.name===saved):null;
    if(!chosen)chosen=candidates.map(v=>({v,s:scoreVoice(v,key)})).sort((a,b)=>b.s-a.s)[0]?.v||null;
    if(chosen)localStorage.setItem(cfg.storage,chosen.name);
    return chosen;
  }
  function loadVoices(){
    if(!('speechSynthesis' in window)){state.status='unsupported';updateUI();return;}
    const list=window.speechSynthesis.getVoices()||[]; state.voices=list;
    state.selected.vi=pick('vi',list); state.selected.en=pick('en',list); state.selected.zh=pick('zh',list);
    const count=Object.values(state.selected).filter(Boolean).length;
    state.ready=count>0; state.status=count===3?'ready':(count?'partial':'missing'); updateUI();
  }
  function shortName(v){return v?(v.name||v.lang||'voice').replace(/Microsoft|Google|Online \(Natural\)|Desktop/gi,'').trim():'chưa có';}
  function isNatural(v){return !!(v&&/natural|neural|premium|enhanced|xiaoxiao|yunxi|jenny|aria|ava|hoai\s*my|nam\s*minh/i.test(v.name||''));}
  function korvaText(){
    const k=window.KorvaVoice;
    if(!k) return 'VI: đang khởi tạo KorvaTTS';
    if(k.state.ready) return `VI: KorvaTTS • ${k.voices[k.state.voice]||k.state.voice} • ${k.state.backend}`;
    if(k.state.status==='loading') return `VI: ${k.state.progress||'đang tải gói giọng tự nhiên…'}`;
    if(k.state.status==='error') return 'VI: KorvaTTS lỗi, đang dùng voice hệ thống dự phòng';
    return 'VI: KorvaTTS chưa nạp (chống treo)';
  }
  function updateUI(){
    const badge=document.getElementById('voicePackStatus'); if(!badge)return;
    const k=window.KorvaVoice;
    const viAI=!!(k&&k.state.ready);
    const en=state.selected.en, zh=state.selected.zh;
    const natural=[en,zh].filter(isNatural).length + (viAI?1:0);
    const ok=(viAI?1:0)+(en?1:0)+(zh?1:0);
    if(k&&k.state.status==='loading'){
      badge.textContent='🎙️ '+(k.state.progress||'Đang tải giọng Việt AI…');
      badge.className='voice-pack-status partial';
    }else if(viAI){
      badge.textContent=`🎙️ Voice AI ${ok}/3 • Natural ${natural}/3`;
      badge.className='voice-pack-status '+(ok===3&&natural>=2?'ready':'partial');
    }else{
      badge.textContent=`🎙️ Voice AI ${ok}/3 • VI đang dùng dự phòng`;
      badge.className='voice-pack-status '+(ok?'partial':'missing');
    }
    badge.title=`${korvaText()}\nEN: ${shortName(en)}\nZH: ${shortName(zh)}`;
  }
  function clean(text){return String(text||'').replace(/<[^>]*>?/gm,'').replace(/\s+/g,' ').trim();}

  function systemSpeakAsync(text,opts={}){
    return new Promise(resolve=>{
      if(!('speechSynthesis' in window)){resolve(false);return;}
      const locale=opts.lang||'vi-VN', key=langKey(locale), u=new SpeechSynthesisUtterance(clean(text));
      u.lang=locale; u.rate=opts.rate||1; u.pitch=opts.pitch||1;
      const v=state.selected[key]; if(v)u.voice=v;
      u.onstart=()=>opts.onstart&&opts.onstart();
      u.onend=()=>{opts.onend&&opts.onend();resolve(true);};
      u.onerror=()=>{opts.onerror&&opts.onerror();resolve(false);};
      window.speechSynthesis.speak(u);
    });
  }

  function speak(text,opts={}){
    const locale=opts.lang||'vi-VN', key=langKey(locale), t=clean(text);
    if(!t)return false;
    if(key==='vi' && window.KorvaVoice){
      window.KorvaVoice.speak(t,opts).then(ok=>{ if(!ok) systemSpeakAsync(t,opts); });
      return true;
    }
    systemSpeakAsync(t,opts); return true;
  }

  function cancelAll(){
    sequenceId++;
    if('speechSynthesis' in window) window.speechSynthesis.cancel();
    if(window.KorvaVoice) window.KorvaVoice.cancel();
  }

  function speakSequence(parts,opts={}){
    if(opts.cancel!==false)cancelAll();
    const id=sequenceId;
    const valid=(parts||[]).filter(p=>p&&clean(p.text)); if(!valid.length)return false;
    (async()=>{
      for(let i=0;i<valid.length;i++){
        if(id!==sequenceId)return;
        const p=valid[i], key=langKey(p.lang||'vi-VN');
        const cfg={lang:p.lang||'vi-VN',rate:p.rate||1,pitch:p.pitch||1,onstart:i===0?opts.onstart:null,onend:i===valid.length-1?opts.onend:null,onerror:i===valid.length-1?opts.onerror:null};
        if(key==='vi'&&window.KorvaVoice){
          const ok=await window.KorvaVoice.speak(p.text,cfg);
          if(!ok && id===sequenceId) await systemSpeakAsync(p.text,cfg);
        }else{
          await systemSpeakAsync(p.text,cfg);
        }
      }
    })();
    return true;
  }
  function openSetup(){
    const k=window.KorvaVoice;
    const viLine=k&&k.state.ready
      ?`🇻🇳 Việt: KorvaTTS — ${k.voices[k.state.voice]||k.state.voice} • ${k.state.backend} • 44.1 kHz`
      :k&&k.state.status==='loading'
        ?`🇻🇳 Việt: ${k.state.progress||'Đang tải gói KorvaTTS…'}`
        :`🇻🇳 Việt: KorvaTTS chưa sẵn sàng${k&&k.state.error?' — '+k.state.error:''}`;
    const low=!!(k&&k.isLikelyLowPower&&k.isLikelyLowPower());
    const lines=[
      'VOICE AI ĐA NGÔN NGỮ', '', viLine,
      `🇬🇧 English: ${state.selected.en?state.selected.en.name+' ['+state.selected.en.lang+']':'Chưa có voice en-US/en-GB'}`,
      `🇨🇳 中文: ${state.selected.zh?state.selected.zh.name+' ['+state.selected.zh.lang+']':'Chưa có voice zh-CN'}`,
      '',
      low?'⚠️ Thiết bị được nhận diện cấu hình thấp. App sẽ KHÔNG tự nạp model Korva nặng để tránh đứng.':'KorvaTTS hiện không tự nạp khi mở web để tránh khóa giao diện.',
      'Nhấn OK để đóng. Muốn tải giọng Việt AI, dùng nút ⬇ Nạp VI riêng bên cạnh nút 🎙️.'
    ]; alert(lines.join('\n'));
  }
  function testAll(){
    speakSequence([
      {text:'Xin chào, cô sẽ đồng hành cùng em trong lớp học thông minh.',lang:'vi-VN',rate:1.0},
      {text:'Hello! Let us practice English with a natural native voice.',lang:'en-US',rate:.96},
      {text:'你好！我们一起学习标准普通话。',lang:'zh-CN',rate:.9}
    ]);
  }
  async function loadVietnameseAI(){
    const k=window.KorvaVoice, btn=document.getElementById('loadViVoiceBtn');
    if(!k){ alert('Engine giọng Việt AI chưa tải xong. Hãy thử lại sau vài giây.'); return false; }
    if(k.state.ready){
      if(btn){btn.textContent='✓ VI AI';btn.className='voice-load-btn ready';}
      testAll();
      return true;
    }
    if(k.state.status==='loading') return false;
    if(btn){btn.disabled=true;btn.textContent='⏳ Đang nạp…';btn.className='voice-load-btn loading';}
    try{
      const ok=await k.forceInit();
      if(ok){
        if(btn){btn.textContent='✓ VI AI';btn.className='voice-load-btn ready';}
        speak('Xin chào, giọng Việt AI tự nhiên đã sẵn sàng.',{lang:'vi-VN',rate:1.0});
      }else{
        if(btn){btn.textContent='↻ Nạp lại VI';btn.className='voice-load-btn error';}
      }
      return !!ok;
    }catch(err){
      if(btn){btn.textContent='↻ Nạp lại VI';btn.className='voice-load-btn error';}
      return false;
    }finally{ if(btn) btn.disabled=false; updateUI(); }
  }
  function syncLoadButton(){
    const k=window.KorvaVoice, btn=document.getElementById('loadViVoiceBtn'); if(!btn||!k)return;
    if(k.state.ready){btn.disabled=false;btn.textContent='✓ VI AI';btn.className='voice-load-btn ready';}
    else if(k.state.status==='loading'){btn.disabled=true;btn.textContent='⏳ Đang nạp…';btn.className='voice-load-btn loading';}
    else if(k.state.status==='error'){btn.disabled=false;btn.textContent='↻ Nạp lại VI';btn.className='voice-load-btn error';}
    else{btn.disabled=false;btn.textContent='⬇ Nạp VI';btn.className='voice-load-btn';}
  }
  window.MultiVoiceManager={state,loadVoices,speak,speakSequence,openSetup,testAll,loadVietnameseAI,cancelAll,getVoice:(locale)=>state.selected[langKey(locale)]};
  window.HanoiVoiceManager=window.MultiVoiceManager;
  if('speechSynthesis' in window)window.speechSynthesis.onvoiceschanged=loadVoices;
  window.addEventListener('korva-status',()=>{updateUI();syncLoadButton();});
  document.addEventListener('DOMContentLoaded',()=>{loadVoices();syncLoadButton();setTimeout(loadVoices,350);setTimeout(loadVoices,1200);setTimeout(()=>{updateUI();syncLoadButton();},1600);});
})();
