(function(){
  window.AI_CLASS_OFFLINE=true;
  const LIVE='https://aihuedanlearn.edgeone.dev/';
  function offlineOnly(msg){ alert(msg||'Tính năng này cần Internet. Bạn vẫn có thể học cá nhân và lưu điểm offline.'); }
  window.openMultiplayerSetup=()=>offlineOnly('Tạo phòng 1v1 cần Internet/Firebase.');
  window.joinRoom=()=>offlineOnly('Vào phòng 1v1 cần Internet/Firebase.');
  window.rejoinLastRoom=()=>offlineOnly('Vào lại phòng 1v1 cần Internet/Firebase.');
  window.addEventListener('DOMContentLoaded',()=>{
    const top=document.querySelector('.top-banner');
    if(top){
      const b=document.createElement('button'); b.textContent='📴 OFFLINE • Thử Online'; b.className='action-top-btn';
      b.style.background='#b45309'; b.onclick=()=>location.href=LIVE; top.appendChild(b);
    }
    const rs=document.getElementById('roomStatusText'); if(rs)rs.textContent='📴 Offline • Học cá nhân';
    const vp=document.getElementById('voicePackStatus'); if(vp){vp.textContent='🎙️ Offline: dùng giọng hệ thống nếu thiết bị có';vp.classList.add('partial');}
    const lv=document.getElementById('loadViVoiceBtn'); if(lv){lv.disabled=true;lv.title='Korva AI cần Internet để tải model lần đầu';lv.textContent='VI AI cần mạng';}
    const info=document.getElementById('roomCodeInfo'); if(info)info.textContent='Offline: phòng 1v1 tạm không khả dụng.';
    const note=document.createElement('div'); note.id='offlineNotice'; note.textContent='📴 Chế độ offline: CEFR, HSK core, Toán/Tiếng Việt/Tiếng Anh 5, điểm & streak vẫn dùng được. Firebase 1v1, tải Korva và dữ liệu nét Hán mới cần mạng.';
    note.style.cssText='position:fixed;left:8px;right:8px;bottom:54px;z-index:3000;background:#7c2d12;color:#fff;padding:6px 10px;border-radius:9px;font-size:11px;box-shadow:0 3px 15px #0008;text-align:center';
    document.body.appendChild(note); setTimeout(()=>{if(note)note.style.opacity='.55'},7000);
  });
})();
