/* Firebase Realtime Database multiplayer layer.
   Host-authoritative: only host changes question/timer/pause and awards points. */
let fbApp=null, fbAuth=null, fbDb=null, fbRoomRef=null, fbRoomCode='', fbRole='', fbUid='';
let fbStateListener=null, fbAnswerListener=null, fbAnswerRef=null, fbRoundId='';
let fbPublishing=false, fbHostStarted=false, fbAdvanceScheduled=false;
const FB_SESSION_KEY='ai_class_fb_session_v3';
const STUDENT_PROFILE_KEY='ai_class_student_profile_v3';

function firebaseReady() {
  const c=window.FIREBASE_CONFIG;
  return !!(window.firebase && c && c.apiKey && c.apiKey!=='YOUR_API_KEY' &&
    c.projectId && c.projectId!=='YOUR_PROJECT_ID' && c.databaseURL &&
    c.databaseURL.indexOf('YOUR_PROJECT_ID')===-1);
}
async function ensureFirebase() {
  if (!firebaseReady()) throw new Error('Chưa cấu hình Firebase. Hãy điền firebase-config.js trước.');
  if (!fbApp) {
    fbApp=firebase.initializeApp(window.FIREBASE_CONFIG);
    fbAuth=firebase.auth(); fbDb=firebase.database();
    try { await fbAuth.setPersistence(firebase.auth.Auth.Persistence.LOCAL); } catch(e) { console.warn('Không đặt được LOCAL auth persistence', e); }
  }
  let user=fbAuth.currentUser;
  if(!user){
    const cred=await fbAuth.signInAnonymously();
    user=cred.user;
  }
  fbUid=user.uid;
  return fbUid;
}
function loadStudentProfile(){
  try{return JSON.parse(localStorage.getItem(STUDENT_PROFILE_KEY)||'{}')||{};}catch(e){return {};}
}
function saveStudentProfile(extra={}){
  try{
    const old=loadStudentProfile();
    const user=STUDENTS&&STUDENTS[0]?STUDENTS[0]:{};
    const next={...old,name:user.name||old.name||'Học viên 01',score:Number(user.score||0),streak:Number(userStreak||0),updatedAt:Date.now(),...extra};
    localStorage.setItem(STUDENT_PROFILE_KEY,JSON.stringify(next));
    return next;
  }catch(e){return {};}
}
function saveRoomSession(extra={}){
  try{
    const old=JSON.parse(localStorage.getItem(FB_SESSION_KEY)||'{}')||{};
    const next={...old,roomCode:fbRoomCode||old.roomCode||'',role:fbRole||old.role||'',uid:fbUid||old.uid||'',name:(STUDENTS[0]&&STUDENTS[0].name)||old.name||'',score:Number((STUDENTS[0]&&STUDENTS[0].score)||old.score||0),updatedAt:Date.now(),...extra};
    localStorage.setItem(FB_SESSION_KEY,JSON.stringify(next));
    saveStudentProfile({lastRoom:next.roomCode,lastRole:next.role});
    return next;
  }catch(e){return {};}
}
function loadRoomSession(){try{return JSON.parse(localStorage.getItem(FB_SESSION_KEY)||'{}')||{};}catch(e){return {};}}
function clearRoomSession(){try{localStorage.removeItem(FB_SESSION_KEY);}catch(e){}}
function friendlyFirebaseError(e){
  const msg=(e&&e.message)||String(e||'');
  if(/permission_denied|permission denied/i.test(msg)) return 'Firebase đang chặn quyền truy cập. Hãy triển khai file database.rules.json đi kèm bản này vào Realtime Database Rules.';
  if(/auth\/operation-not-allowed|anonymous/i.test(msg)) return 'Firebase Anonymous Authentication chưa được bật. Hãy bật Authentication > Sign-in method > Anonymous.';
  return msg;
}
function roomCode6(){ return String(Math.floor(100000+Math.random()*900000)); }
function setRoomMessage(msg, bad=false) {
  const el=document.getElementById('roomCodeInfo');
  if(el){el.textContent=msg;el.style.color=bad?'#fca5a5':'#a8e6cf';}
}
function roomTools(host) {
  const box=document.getElementById('multiplayerBox');
  if(!box)return;
  let tools=box.querySelector('.room-tools');
  if(!tools){tools=document.createElement('div');tools.className='room-tools';box.appendChild(tools);}
  tools.innerHTML=host
    ? '<button onclick="copyRoomInvite()">📋 Sao chép lời mời</button><button onclick="hostStartClass()">▶️ Bắt đầu lớp</button><button class="secondary" onclick="leaveRoom()">Đóng phòng</button>'
    : '<button class="secondary" onclick="leaveRoom()">Rời phòng</button>';
}
async function openMultiplayerSetup() {
  const name=document.getElementById('userNameInput').value.trim()||'Chủ Phòng';
  STUDENTS[0].name=name; isHost=true; isSolo=false;
  const box=document.getElementById('multiplayerBox'); box.style.display='flex';
  setRoomMessage('Đang xác thực và tạo phòng trên Firebase...');
  try {
    await ensureFirebase();
    let created=false, code='';
    for(let i=0;i<8 && !created;i++){
      code=roomCode6();
      const ref=fbDb.ref('rooms/'+code);
      const result=await ref.transaction(current=>{
        if(current===null) return {
          hostUid:fbUid, hostName:name, status:'waiting', createdAt:firebase.database.ServerValue.TIMESTAMP,
          players:{[fbUid]:{name,role:'host',score:0,avatar:'🧑‍🏫'}},
          state:{appMode:'english',currentSubCategory:'A1',questionIndex:0,timer:20,isPaused:false,roundId:'round-0',started:false}
        };
        return;
      },undefined,false);
      if(result.committed){created=true;fbRoomRef=ref;fbRoomCode=code;}
    }
    if(!created) throw new Error('Không tạo được mã phòng duy nhất. Vui lòng thử lại.');
    fbRole='host'; myRoomCode=fbRoomCode; saveRoomSession({roomCode:fbRoomCode,role:'host',score:STUDENTS[0].score||0,name});
    setRoomMessage('✅ Phòng #'+fbRoomCode+' đã tạo. Chờ khách tham gia.');
    roomTools(true); document.getElementById('roomStatusText').innerText='🟡 Đang chờ khách tham gia';
    listenAsHost();
  } catch(e) { setRoomMessage('❌ '+friendlyFirebaseError(e),true); console.error(e); }
}
async function joinRoom() {
  const code=document.getElementById('joinCodeInput').value.trim();
  const name=document.getElementById('userNameInput').value.trim()||'Học viên khách';
  if(!/^\d{6}$/.test(code)){alert('Vui lòng nhập mã phòng gồm đúng 6 chữ số.');return;}
  isHost=false;isSolo=false;STUDENTS[0].name=name;
  document.getElementById('roomStatusText').innerText='Đang xác thực và tìm phòng #'+code+'...';
  document.getElementById('multiplayerBox').style.display='flex';
  setRoomMessage('Đang kết nối Firebase...');
  try{
    await ensureFirebase();
    const ref=fbDb.ref('rooms/'+code);
    const snap=await ref.once('value');
    if(!snap.exists()) throw new Error('Không tồn tại phòng này. Kiểm tra lại mã hoặc yêu cầu chủ phòng tạo phòng mới.');
    const room=snap.val();
    if(room.status!=='waiting' && room.status!=='active') throw new Error('Phòng đã đóng hoặc không nhận khách.');
    if(room.hostUid===fbUid) throw new Error('Bạn không thể tham gia phòng do chính mình tạo trên cùng tài khoản.');

    // Cho phép đúng khách cũ chiếm lại chính guestUid của mình sau khi reload.
    const claim=await ref.child('guestUid').transaction(v=>(v===null||v===fbUid)?fbUid:undefined,undefined,false);
    if(!claim.committed) throw new Error('Phòng đã có khách khác. Mỗi phòng chỉ hỗ trợ 1 chủ phòng và 1 khách.');

    const oldPlayerSnap=await ref.child('players/'+fbUid).once('value');
    const oldPlayer=oldPlayerSnap.val()||{};
    const localSession=loadRoomSession();
    // Điểm trong phòng do host quản lý. Khi reconnect chỉ lấy lại đúng điểm đã tồn tại trên Firebase.
    // Điểm tổng cá nhân vẫn được lưu local qua STUDENT_PROFILE_KEY.
    const score=oldPlayerSnap.exists()?Number(oldPlayer.score||0):0;
    await ref.child('players/'+fbUid).update({
      name,role:'guest',score,avatar:'👩‍🎓',
      joinedAt:oldPlayer.joinedAt||firebase.database.ServerValue.TIMESTAMP,
      lastSeenAt:firebase.database.ServerValue.TIMESTAMP,
      reconnects:Number(oldPlayer.reconnects||0)+1
    });

    fbRoomRef=ref;fbRoomCode=code;fbRole='guest';myRoomCode=code;STUDENTS[0].score=score;
    saveRoomSession({roomCode:code,role:'guest',score,name});
    setRoomMessage(oldPlayerSnap.exists()?'✅ Đã vào lại phòng #'+code+' và khôi phục điểm.':'✅ Đã vào phòng #'+code+'. Đang đồng bộ lớp học...');
    roomTools(false);
    document.getElementById('roomStatusText').innerText='🟢 Đã vào lớp – chờ chủ phòng bắt đầu';
    listenAsGuest();
  }catch(e){const msg=friendlyFirebaseError(e);setRoomMessage('❌ '+msg,true);document.getElementById('roomStatusText').innerText='Kết nối thất bại';console.error(e);}
}
function listenAsHost(){
  if(!fbRoomRef)return;
  if(fbAnswerListener)fbAnswerListener.off();
  fbAnswerRef=fbRoomRef.child('answers');
  fbAnswerListener=fbAnswerRef;
  fbAnswerRef.on('child_added',snap=>{
    const a=snap.val(); if(!a||a.roundId!==fbRoundId)return;
    processGuestAnswer(snap.key,a);
  });
  fbRoomRef.child('players').on('value',snap=>{
    const players=snap.val()||{};
    const guest=Object.entries(players).find(([id,p])=>p.role==='guest');
    let st=STUDENTS.find(x=>x.id==='peer');
    if(guest){
      if(!st){st={id:'peer',name:guest[1].name,avatar:'👩‍🎓',score:0,isFriend:true,answered:false,lastAns:''};STUDENTS.push(st);}
      st.name=guest[1].name;st.score=guest[1].score||0;renderClassroom();
      document.getElementById('roomStatusText').innerText='🟢 Đã kết nối với '+st.name;
    }
  });
}
function listenAsGuest(){
  fbRoomRef.child('state').on('value',snap=>{
    const s=snap.val();if(!s)return;
    const changed=s.roundId!==fbRoundId;
    appMode=s.appMode||'english';currentSubCategory=(typeof normalizeLearningSub==='function'?normalizeLearningSub(appMode,s.currentSubCategory):((appMode==='english')?'A1':s.currentSubCategory));questionIndex=s.questionIndex||0;
    isPaused=!!s.isPaused;timer=Number.isFinite(s.timer)?s.timer:20;
    if(changed){
      fbRoundId=s.roundId;toggleLangModelUI();loadQuestionLocal(true);
    }
    document.getElementById('timerDisplay').innerText=timer;
    document.getElementById('pauseBtn').innerText=isPaused?'▶️ Chờ chủ phòng':'⏸️ Chủ phòng điều khiển';
    document.getElementById('pauseBtn').disabled=true;
    if(s.started){
      document.getElementById('setupModal').classList.remove('open');
      document.getElementById('roomStatusText').innerText='🟢 Đang học cùng chủ phòng';
    }
    applyPlayers(s.players);
  });
}
function applyPlayers(players){
  if(!players)return;
  const entries=Object.entries(players);
  const me=entries.find(([id])=>id===fbUid);
  const other=entries.find(([id])=>id!==fbUid);
  if(me){STUDENTS[0].score=me[1].score||0;STUDENTS[0].name=me[1].name||STUDENTS[0].name;saveRoomSession({score:STUDENTS[0].score,name:STUDENTS[0].name});saveStudentProfile();}
  STUDENTS=STUDENTS.filter(s=>s.id!=='peer');
  if(other){STUDENTS.push({id:'peer',name:other[1].name||'Bạn học',avatar:other[1].avatar||'🧑‍🎓',score:other[1].score||0,isFriend:true,answered:!!other[1].answered,lastAns:other[1].lastAns||''});}
  document.getElementById('streakText').innerText='🔥 Điểm của bạn: '+STUDENTS[0].score+'đ';
  renderClassroom();
}
function publishRoomState(){
  if(fbRole!=='host'||!fbRoomRef||fbPublishing)return;
  fbPublishing=true;
  const players={};
  players[fbUid]={name:STUDENTS[0].name,role:'host',score:STUDENTS[0].score||0,avatar:'🧑‍🏫',answered:!!STUDENTS[0].answered,lastAns:STUDENTS[0].lastAns||''};
  const guest=STUDENTS.find(s=>s.id==='peer');
  fbRoomRef.child('players').once('value').then(snap=>{
    const old=snap.val()||{};
    const guestEntry=Object.entries(old).find(([id,p])=>id!==fbUid&&p.role==='guest');
    if(guestEntry)players[guestEntry[0]]={...guestEntry[1],score:guest.score||guestEntry[1].score||0,answered:!!guest.answered,lastAns:guest.lastAns||''};
    const state={appMode,currentSubCategory,questionIndex,timer,isPaused,roundId:fbRoundId||('round-'+questionIndex),started:fbHostStarted,players,updatedAt:firebase.database.ServerValue.TIMESTAMP};
    return fbRoomRef.update({state,players});
  }).catch(console.error).finally(()=>{fbPublishing=false;});
}
function hostStartClass(){
  if(fbRole!=='host'||!fbRoomRef)return;
  fbHostStarted=true;isPaused=false;document.getElementById('setupModal').classList.remove('open');
  fbRoomRef.update({status:'active'}).then(()=>{
    fbRoundId='round-'+Date.now();loadQuestion();publishRoomState();
    document.getElementById('roomStatusText').innerText='🟢 Lớp đang hoạt động';
    teacherSpeak('Lớp học bắt đầu! Chúc hai bạn học tốt.');
  });
}
function copyRoomInvite(){
  if(!fbRoomCode)return;
  const link=location.origin+location.pathname+'?room='+fbRoomCode;
  const msg='Mời bạn vào lớp học AI. Mã phòng: '+fbRoomCode+'\n'+link;
  if(navigator.share){navigator.share({title:'Mời vào lớp học AI',text:msg,url:link}).catch(()=>{});}
  else if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(msg).then(()=>alert('Đã sao chép lời mời.')).catch(()=>alert(msg));}
  else alert(msg);
}
function processGuestAnswer(uid,a){
  if(fbRole!=='host'||!fbRoomRef||a.roundId!==fbRoundId)return;
  const ref=fbRoomRef.child('answers/'+uid);
  ref.remove();
  const guest=STUDENTS.find(s=>s.id==='peer');if(!guest||guest.answered)return;
  let correct=false;
  if(appMode==='english')correct=String(a.answer||'').trim().toUpperCase().replace(/[^A-Z]/g,'')===currentItem.word;
  else correct=!!a.correct;
  if(!correct)return;
  const bonus=Math.max(5,Math.min(20,Number(a.bonus)||10));
  guest.score=(guest.score||0)+bonus;guest.answered=true;
  guest.lastAns=appMode==='english'?currentItem.word.toLowerCase():'Đúng';
  renderClassroom();addFeedMessage(guest.name,'(+'+bonus+'đ)',true);
  fbRoomRef.child('players/'+uid).update({score:guest.score,answered:true,lastAns:guest.lastAns});
  publishRoomState();
  if(!roundSolvedByUser){
    roundSolvedByUser=true; clearInterval(timerInterval);
    if(!fbAdvanceScheduled){
      fbAdvanceScheduled=true;
      setTimeout(()=>{fbAdvanceScheduled=false;if(fbRole==='host'&&fbHostStarted){questionIndex++;loadQuestion();}},3000);
    }
  }
}
function scorePoints(method,bonus){
  if(roundSolvedByUser||isPaused)return;
  if(fbRole==='guest'&&fbRoomRef){
    if(window.LearningHub)LearningHub.recordSuccess(currentItem,bonus,method);
    roundSolvedByUser=true;
    const answer=appMode==='english'?currentItem.word:'CORRECT';
    fbRoomRef.child('answers/'+fbUid).set({roundId:fbRoundId,answer,correct:true,bonus:Number(bonus)||10,method,at:firebase.database.ServerValue.TIMESTAMP});
    teacherSpeak('Đã gửi bài cho cô giáo AI. Cô đang kiểm tra và đồng bộ điểm cho em nhé.');
    clearInterval(timerInterval);return;
  }
  if(fbRole==='host'&&fbRoomRef){
    if(window.LearningHub)LearningHub.recordSuccess(currentItem,bonus,method);
    roundSolvedByUser=true;userStreak++;
    STUDENTS[0].score+=bonus;STUDENTS[0].answered=true;
    STUDENTS[0].lastAns=appMode==='english'?currentItem.word.toLowerCase():'Đúng';
    document.getElementById('streakText').innerText=`🔥 Chuỗi: ${userStreak} | ${STUDENTS[0].score}đ`;
    renderClassroom();addFeedMessage(STUDENTS[0].name,`(+${bonus}đ qua ${method})`,true);
    fbRoomRef.child('players/'+fbUid).update({score:STUDENTS[0].score,answered:true,lastAns:STUDENTS[0].lastAns});saveRoomSession({score:STUDENTS[0].score});saveStudentProfile();
    publishRoomState();clearInterval(timerInterval);
    if(!fbAdvanceScheduled){
      fbAdvanceScheduled=true;
      setTimeout(()=>{fbAdvanceScheduled=false;if(fbRole==='host'&&fbHostStarted){questionIndex++;loadQuestion();}},3000);
    }
    return;
  }
  if(window.LearningHub)LearningHub.recordSuccess(currentItem,bonus,method);
  roundSolvedByUser=true;userStreak++;
  const userObj=STUDENTS[0];userObj.score+=bonus;userObj.answered=true;
  userObj.lastAns=appMode==='english'?currentItem.word.toLowerCase():'Đúng';
  document.getElementById('streakText').innerText=`🔥 Chuỗi: ${userStreak} | ${userObj.score}đ`;
  renderClassroom();addFeedMessage(userObj.name,`(+${bonus}đ qua ${method})`,true);
  saveStudentProfile();
  teacherSpeak(`Giỏi lắm ${userObj.name}! Trả lời xuất sắc!`);
  clearInterval(timerInterval);setTimeout(()=>{questionIndex++;loadQuestion();},3500);
}
function loadQuestion(){
  if(fbRole==='guest'){return;}
  loadQuestionLocal();
  if(fbRole==='host'&&fbRoomRef){
    fbRoundId='round-'+Date.now()+'-'+questionIndex;
    publishRoomState();
  }
}
function nextQuestionManually(){
  if(fbRole==='guest'){alert('Chỉ chủ phòng mới được chuyển câu hỏi.');return;}
  questionIndex++;loadQuestion();teacherSpeak('Chuyển sang bài tiếp theo nhé!');
}
function togglePauseGame(){
  if(fbRole==='guest'){alert('Chủ phòng đang điều khiển lớp học.');return;}
  isPaused=!isPaused;document.getElementById('pauseBtn').innerText=isPaused?'▶️ Tiếp Tục':'⏸️ Tạm Dừng';
  if(fbRole==='host'&&fbRoomRef){fbRoomRef.child('state/isPaused').set(isPaused);publishRoomState();}
  teacherSpeak(isPaused?'Lớp học đã tạm dừng.':'Lớp học tiếp tục nhé!');
}
function changeModeAndSync(mode,sub,source='program'){
  if(fbRole==='guest'){alert('Chỉ chủ phòng mới được đổi chương trình.');return;}
  setAppMode(mode,sub,source);
  // setAppMode() đã normalize state + render lại thanh chương trình.
  // Chỉ publish sau khi UI/state đã thống nhất.
  if(fbRole==='host'&&fbRoomRef)publishRoomState();
}
function switchTopic(sub){
  if(fbRole==='guest'){alert('Chỉ chủ phòng mới được đổi chủ đề.');return;}
  const prev=currentSubCategory;
  currentSubCategory = (typeof normalizeLearningSub==='function') ? normalizeLearningSub(appMode,sub) : sub;
  questionIndex=0;
  if(prev!==currentSubCategory){
    if(typeof englishDeckState!=='undefined' && englishDeckState[currentSubCategory]) delete englishDeckState[currentSubCategory];
    if(typeof grade5DeckState!=='undefined' && grade5DeckState[appMode+':'+currentSubCategory]) delete grade5DeckState[appMode+':'+currentSubCategory];
  }
  if(typeof toggleLangModelUI==='function') toggleLangModelUI();
  loadQuestion();
  if(fbRole==='host'&&fbRoomRef)publishRoomState();
}
function revealAndNext(){
  if(fbRole==='guest')return;
  if(appMode==='english'){
    currentAnswerChars=currentItem.word.split('').map((c,i)=>({char:c,id:i}));
    renderBoardSlots();teacherSpeak('Hết giờ! Đáp án là '+currentItem.word+'.');
  }
  setTimeout(()=>{if(fbRole!=='guest'){questionIndex++;loadQuestion();}},3000);
}
function leaveRoom(){
  const role=fbRole;
  if(fbRoomRef&&role==='host'){
    fbRoomRef.update({status:'closed'}).catch(console.error);
    clearRoomSession();
  }else if(fbRoomRef&&role==='guest'&&fbUid){
    // Rời chủ động thì nhường chỗ cho khách khác; reload/tab crash KHÔNG gọi hàm này nên vẫn vào lại được.
    fbRoomRef.child('players/'+fbUid).remove().catch(console.error);
    fbRoomRef.child('guestUid').transaction(v=>v===fbUid?null:v).catch(console.error);
    clearRoomSession();
  }
  if(fbRoomRef){fbRoomRef.off();if(fbAnswerRef)fbAnswerRef.off();}
  fbRoomRef=null;fbRoomCode='';fbRole='';fbHostStarted=false;fbAdvanceScheduled=false;isSolo=true;isHost=false;
  document.getElementById('pauseBtn').disabled=false;
  document.getElementById('setupModal').classList.add('open');
  document.getElementById('multiplayerBox').style.display='none';
  document.getElementById('roomStatusText').innerText='Đã rời phòng';
}
async function rejoinLastRoom(){
  const sess=loadRoomSession();
  if(!sess.roomCode){alert('Chưa có phòng gần nhất được lưu trên thiết bị này.');return;}
  document.getElementById('joinCodeInput').value=sess.roomCode;
  if(sess.name)document.getElementById('userNameInput').value=sess.name;
  await joinRoom();
}
(function initRoomLink(){
  const urlCode=new URLSearchParams(location.search).get('room');
  const sess=loadRoomSession();
  const profile=loadStudentProfile();
  const code=urlCode||sess.roomCode||'';
  if(profile.name)document.getElementById('userNameInput').value=profile.name;
  if(code){
    document.getElementById('joinCodeInput').value=code;
    document.getElementById('multiplayerBox').style.display='flex';
  }
  if(profile.score>0){STUDENTS[0].score=Number(profile.score)||0;userStreak=Number(profile.streak)||0;document.getElementById('streakText').innerText=`🔥 Chuỗi: ${userStreak} | ${STUDENTS[0].score}đ`;}
  const btn=document.getElementById('rejoinLastRoomBtn');
  if(btn)btn.style.display=sess.roomCode?'block':'none';
})();
